import React from 'react';
import { MessageCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';

export const WhatsAppFloatingButton: React.FC = () => {
  const { settings } = useCart();
  const whatsappPhone = settings?.whatsapp_number || '2349024971419';
  const displayPhone = settings?.phone_display || '09024971419';

  const defaultMessage = encodeURIComponent(
    'Hello Mary Restaurant! I would like to place an order or make an inquiry.'
  );

  return (
    <aside aria-label="WhatsApp quick contact" className="fixed bottom-6 right-6 z-40 group">
      <a
        href={`https://wa.me/${whatsappPhone}?text=${defaultMessage}`}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-3 bg-emerald-600 hover:bg-emerald-700 text-white pl-4 pr-5 py-3 rounded-full shadow-2xl transition-all duration-300 transform hover:scale-105 focus:outline-none focus-visible:ring-4 focus-visible:ring-emerald-400"
        aria-label="Order or contact Mary Restaurant on WhatsApp"
      >
        <div className="relative">
          <MessageCircle className="w-6 h-6 fill-current" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-300 rounded-full animate-ping" />
        </div>
        <div className="text-left hidden sm:block">
          <span className="block text-[10px] font-bold uppercase tracking-wider text-emerald-100">
            Order on WhatsApp
          </span>
          <span className="block text-xs font-semibold leading-none">
            {displayPhone}
          </span>
        </div>
      </a>
    </aside>
  );
};
