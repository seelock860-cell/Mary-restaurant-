import React, { useState } from 'react';
import { 
  Building2, 
  Copy, 
  Check, 
  CreditCard, 
  AlertCircle, 
  ShieldCheck, 
  ArrowLeft, 
  Truck, 
  Store,
  Phone,
  User,
  MapPin,
  FileText
} from 'lucide-react';
import { useCart } from '../context/CartContext';
import { api } from '../services/api';
import { PageRoute, PaymentMethod, Order } from '../types';

interface CheckoutPageProps {
  setCurrentPage: (page: PageRoute) => void;
  setConfirmedOrder: (order: Order) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({
  setCurrentPage,
  setConfirmedOrder,
}) => {
  const {
    cart,
    subtotal,
    deliveryFee,
    total,
    deliveryMethod,
    setDeliveryMethod,
    clearCart,
    formatNaira,
    settings,
  } = useCart();

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [deliveryInstructions, setDeliveryInstructions] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('bank_transfer');
  const [paymentReference, setPaymentReference] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedAccount, setCopiedAccount] = useState(false);

  const bankName = settings?.bank_name || 'Zenith Bank';
  const accountName = settings?.bank_account_name || 'MARY RESTAURANT ENTERPRISES';
  const accountNumber = settings?.bank_account_number || '1018944521';

  const handleCopyAccount = () => {
    navigator.clipboard.writeText(accountNumber);
    setCopiedAccount(true);
    setTimeout(() => setCopiedAccount(false), 2500);
  };

  const validatePhone = (phone: string) => {
    const cleaned = phone.replace(/[\s-]/g, '');
    return /^(0|234|\+234)[789][01]\d{8}$/.test(cleaned);
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!customerName.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }

    if (!customerPhone.trim()) {
      setErrorMessage('Please enter your active phone number.');
      return;
    }

    if (!validatePhone(customerPhone)) {
      setErrorMessage('Please enter a valid Nigerian phone number (e.g., 08012345678 or 09024971419).');
      return;
    }

    if (deliveryMethod === 'delivery' && !deliveryAddress.trim()) {
      setErrorMessage('Please provide a complete delivery address for dispatch.');
      return;
    }

    if (cart.length === 0) {
      setErrorMessage('Your cart is empty. Please add food items before checking out.');
      return;
    }

    setIsSubmitting(true);

    try {
      const itemsPayload = cart.map((item) => ({
        product_id: item.product.id,
        quantity: item.quantity,
      }));

      const res = await api.createOrder({
        customer_name: customerName.trim(),
        customer_phone: customerPhone.trim(),
        delivery_address: deliveryMethod === 'delivery' ? deliveryAddress.trim() : 'Pickup at Restaurant',
        delivery_method: deliveryMethod,
        delivery_instructions: deliveryInstructions.trim(),
        payment_method: paymentMethod,
        payment_reference: paymentReference.trim() || undefined,
        items: itemsPayload,
      });

      if (res.success && res.order) {
        clearCart();
        setConfirmedOrder(res.order);
        setCurrentPage('order-confirmation');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        setErrorMessage('Failed to create order. Please try again.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An error occurred while submitting your order.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="mb-6">
        <button
          onClick={() => setCurrentPage('cart')}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-stone-600 hover:text-red-700 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Shopping Cart</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-7 space-y-6">
          <form onSubmit={handleSubmitOrder} className="space-y-6">
            <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-7 shadow-sm space-y-5">
              <div className="border-b border-stone-100 pb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-red-700">Step 1</span>
                <h2 className="text-lg sm:text-xl font-bold text-stone-900 font-serif">
                  Customer & Delivery Details
                </h2>
              </div>

              {errorMessage && (
                <div className="p-3.5 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2.5 text-red-700 text-xs sm:text-sm">
                  <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-red-600" />
                  <span>{errorMessage}</span>
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
                    Full Name *
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. Babatunde Fashola"
                      className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-600 focus:bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
                    Phone Number (Nigerian Format) *
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="e.g. 08023456789 or 09024971419"
                      className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-600 focus:bg-white"
                    />
                  </div>
                  <span className="text-[11px] text-stone-500 mt-1 block">
                    Our dispatch rider and kitchen will contact this number for delivery.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
                    Order Delivery Method *
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setDeliveryMethod('delivery')}
                      className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
                        deliveryMethod === 'delivery'
                          ? 'border-red-600 bg-red-50 text-red-900 font-bold'
                          : 'border-stone-200 bg-stone-50 text-stone-700'
                      }`}
                    >
                      <Truck className="w-4 h-4 text-red-700" />
                      <div>
                        <span className="block text-xs sm:text-sm">Doorstep Delivery</span>
                        <span className="block text-[11px] font-normal text-stone-500">
                          {formatNaira(settings?.delivery_fee || 1500)}
                        </span>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setDeliveryMethod('pickup')}
                      className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
                        deliveryMethod === 'pickup'
                          ? 'border-red-600 bg-red-50 text-red-900 font-bold'
                          : 'border-stone-200 bg-stone-50 text-stone-700'
                      }`}
                    >
                      <Store className="w-4 h-4 text-red-700" />
                      <div>
                        <span className="block text-xs sm:text-sm">Self Pickup</span>
                        <span className="block text-[11px] font-normal text-emerald-700 font-semibold">
                          FREE
                        </span>
                      </div>
                    </button>
                  </div>
                </div>

                {deliveryMethod === 'delivery' && (
                  <div>
                    <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
                      Delivery Address in Lagos *
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3.5 top-3 w-4 h-4 text-stone-400" />
                      <textarea
                        required
                        rows={2}
                        value={deliveryAddress}
                        onChange={(e) => setDeliveryAddress(e.target.value)}
                        placeholder="House / Flat Number, Street Name, Estate, Area (e.g. Lekki, Ikeja, Ikoyi, Yaba)..."
                        className="w-full pl-10 pr-4 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-600 focus:bg-white"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
                    Special Preparation / Delivery Instructions (Optional)
                  </label>
                  <div className="relative">
                    <FileText className="absolute left-3.5 top-3 w-4 h-4 text-stone-400" />
                    <textarea
                      rows={2}
                      value={deliveryInstructions}
                      onChange={(e) => setDeliveryInstructions(e.target.value)}
                      placeholder="e.g. Mild pepper, pack soup and swallow in separate bowls, call when at security gate..."
                      className="w-full pl-10 pr-4 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-600 focus:bg-white"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-stone-200 p-6 sm:p-7 shadow-sm space-y-5">
              <div className="border-b border-stone-100 pb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-red-700">Step 2</span>
                <h2 className="text-lg sm:text-xl font-bold text-stone-900 font-serif">
                  Select Payment Method
                </h2>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label
                  className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                    paymentMethod === 'bank_transfer'
                      ? 'border-red-600 bg-red-50/40 text-stone-900'
                      : 'border-stone-200 hover:border-stone-300 text-stone-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="bank_transfer"
                      checked={paymentMethod === 'bank_transfer'}
                      onChange={() => setPaymentMethod('bank_transfer')}
                      className="text-red-600 focus:ring-red-600"
                    />
                    <Building2 className="w-5 h-5 text-red-700" />
                    <span className="font-bold text-sm">Direct Bank Transfer</span>
                  </div>
                  <span className="text-xs text-stone-500 mt-2 block">
                    Transfer directly to Mary Restaurant's verified Nigerian bank account.
                  </span>
                </label>

                <label
                  className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                    paymentMethod === 'online_payment'
                      ? 'border-red-600 bg-red-50/40 text-stone-900'
                      : 'border-stone-200 hover:border-stone-300 text-stone-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="online_payment"
                      checked={paymentMethod === 'online_payment'}
                      onChange={() => setPaymentMethod('online_payment')}
                      className="text-red-600 focus:ring-red-600"
                    />
                    <CreditCard className="w-5 h-5 text-red-700" />
                    <span className="font-bold text-sm">Pay Online (Card / USSD)</span>
                  </div>
                  <span className="text-xs text-stone-500 mt-2 block">
                    Instant payment via Paystack gateway with Debit Card or Bank USSD.
                  </span>
                </label>
              </div>

              {paymentMethod === 'bank_transfer' && (
                <div className="p-5 bg-stone-900 text-white rounded-2xl border border-stone-800 space-y-4 animate-fadeIn">
                  <div className="flex items-center justify-between border-b border-stone-800 pb-3">
                    <div className="flex items-center gap-2">
                      <Building2 className="w-5 h-5 text-red-400" />
                      <span className="font-bold text-sm text-stone-100">
                        Official Restaurant Bank Account
                      </span>
                    </div>
                    <span className="text-[10px] uppercase font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                      Verified
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-stone-400 block uppercase tracking-wider text-[10px]">Bank Name</span>
                      <strong className="text-stone-100 text-sm font-semibold">{bankName}</strong>
                    </div>

                    <div>
                      <span className="text-stone-400 block uppercase tracking-wider text-[10px]">Account Name</span>
                      <strong className="text-stone-100 text-sm font-semibold">{accountName}</strong>
                    </div>

                    <div className="sm:col-span-2 bg-stone-800/80 p-3 rounded-xl flex items-center justify-between">
                      <div>
                        <span className="text-stone-400 block uppercase tracking-wider text-[10px]">Account Number</span>
                        <span className="text-xl font-mono font-extrabold text-amber-400 tracking-wider">
                          {accountNumber}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={handleCopyAccount}
                        className="bg-stone-700 hover:bg-stone-600 text-white text-xs font-bold py-2 px-3 rounded-lg flex items-center gap-1.5 transition-colors"
                      >
                        {copiedAccount ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-300 mb-1">
                      Payment Reference / Sender's Bank & Name (Optional)
                    </label>
                    <input
                      type="text"
                      value={paymentReference}
                      onChange={(e) => setPaymentReference(e.target.value)}
                      placeholder="e.g. Zenith transfer by Babatunde Fashola"
                      className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-lg text-xs text-white placeholder-stone-500 focus:outline-none focus:ring-1 focus:ring-red-500"
                    />
                  </div>

                  <p className="text-[11px] text-stone-400 leading-relaxed border-t border-stone-800/80 pt-2">
                    <strong>Note:</strong> Bank transfers will be verified by the restaurant administrator 
                    before food is dispatched. You can also send proof of transfer directly to our kitchen WhatsApp.
                  </p>
                </div>
              )}

              {paymentMethod === 'online_payment' && (
                <div className="p-4 bg-red-50/70 border border-red-200 rounded-xl space-y-2 text-xs text-red-900 animate-fadeIn">
                  <div className="font-bold flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-red-700" />
                    <span>Secure Online Gateway</span>
                  </div>
                  <p>
                    Pay instantly using Mastercard, Visa, Verve, or Nigerian Bank USSD. 
                    Your order payment status will be updated immediately upon authorization.
                  </p>
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-red-700 hover:bg-red-800 disabled:bg-stone-400 text-white font-bold py-4 px-6 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 text-base active:scale-[0.99]"
            >
              {isSubmitting ? (
                <>
                  <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Calculating and Submitting Order...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-5 h-5" />
                  <span>Confirm and Place Order ({formatNaira(total)})</span>
                </>
              )}
            </button>
          </form>
        </div>

        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm space-y-5 sticky top-28">
            <h3 className="font-bold text-stone-900 font-serif text-lg border-b border-stone-100 pb-3">
              Review Your Order
            </h3>

            <div className="max-h-60 overflow-y-auto space-y-3 divide-y divide-stone-100 pr-1">
              {cart.map(({ product, quantity }) => (
                <div key={product.id} className="pt-2 flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2.5">
                    <span className="font-bold text-stone-900 bg-stone-100 px-2 py-0.5 rounded">
                      {quantity}x
                    </span>
                    <span className="font-medium text-stone-800 line-clamp-1">
                      {product.name}
                    </span>
                  </div>
                  <span className="font-bold text-stone-900 shrink-0">
                    {formatNaira(product.price * quantity)}
                  </span>
                </div>
              ))}
            </div>

            <div className="space-y-2.5 pt-3 border-t border-stone-100 text-xs sm:text-sm">
              <div className="flex justify-between text-stone-600">
                <span>Subtotal</span>
                <span className="font-semibold text-stone-900">{formatNaira(subtotal)}</span>
              </div>

              <div className="flex justify-between text-stone-600">
                <span>Fulfilment</span>
                <span className="font-semibold text-stone-900">
                  {deliveryMethod === 'delivery' ? `Delivery (${formatNaira(deliveryFee)})` : 'Self Pickup (Free)'}
                </span>
              </div>

              <div className="pt-3 border-t border-stone-200 flex justify-between items-baseline">
                <span className="text-base font-bold text-stone-950 font-serif">Total Payable</span>
                <span className="text-2xl font-black text-red-700">{formatNaira(total)}</span>
              </div>
            </div>

            <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 text-[11px] text-stone-600 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-stone-800">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Zero-Trust Server Validation</span>
              </div>
              <p>
                All prices and dish availability are re-calculated securely on our backend.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
