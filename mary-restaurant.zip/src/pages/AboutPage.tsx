import React from 'react';
import { 
  Heart, 
  Flame, 
  Sparkles, 
  ShieldCheck, 
  Users, 
  ArrowRight,
  Phone,
  Utensils
} from 'lucide-react';
import { PageRoute } from '../types';
import { useCart } from '../context/CartContext';

interface AboutPageProps {
  setCurrentPage: (page: PageRoute) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ setCurrentPage }) => {
  const { settings } = useCart();
  const whatsappPhone = settings?.whatsapp_number || '2349024971419';

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Banner */}
      <section className="bg-gradient-to-b from-[#f7f2ea] to-[#faf7f2] border-b border-stone-200/60 py-16 sm:py-20 text-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <span className="text-xs font-bold uppercase tracking-wider text-red-700">
            Our Culinary Heritage
          </span>
          <h1 className="text-3xl sm:text-5xl font-black text-stone-950 font-serif">
            Rooted in Tradition, Prepared with Passion
          </h1>
          <p className="text-base sm:text-lg text-stone-700 max-w-2xl mx-auto leading-relaxed">
            MARY RESTAURANT was founded on a simple, timeless mission: to serve 
            authentic, soulful Nigerian meals that remind you of home, celebrations, and 
            the warmth of family.
          </p>
        </div>
      </section>

      {/* Story Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-5">
            <span className="text-xs font-bold uppercase tracking-wider text-red-700">
              The Mary Restaurant Story
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-stone-950 font-serif leading-snug">
              From Grandmother’s Firewood Hearth to Lagos’s Favorite Kitchen
            </h2>
            <p className="text-stone-700 text-sm sm:text-base leading-relaxed">
              Growing up, our founder Mary learned that great Nigerian cooking cannot be rushed. 
              The smoky aroma of party jollof comes from slow reduction of ripe plum tomatoes, 
              tatase, and rodo peppers. The silky glide of Ogbono and Okra requires hand-pounded 
              crayfish and authentic smoked stockfish from the southern delta.
            </p>
            <p className="text-stone-700 text-sm sm:text-base leading-relaxed">
              Today, from our kitchen in Victoria Island, Lagos, we uphold those sacred standards 
              every single morning. We wake before dawn to source fresh ugwu, bitterleaf, 
              and soko from local markets, select prime cuts of tender goat meat and beef, and 
              pound our yam to soft, stretchy perfection.
            </p>

            <div className="pt-2">
              <button
                onClick={() => {
                  setCurrentPage('menu');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="inline-flex items-center gap-2 bg-red-700 hover:bg-red-800 text-white font-bold py-3.5 px-6 rounded-xl text-sm shadow-md transition-all"
              >
                <span>Taste Our Signature Dishes</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="relative">
            <div className="rounded-3xl overflow-hidden shadow-2xl border-2 border-white bg-stone-100">
              <img
                src="https://images.unsplash.com/photo-1543339308-43e59d6b73a6?w=800&auto=format&fit=crop&q=80"
                alt="Chef preparing authentic Nigerian soup with pounded yam"
                className="w-full h-96 object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-stone-900 text-white p-5 rounded-2xl shadow-xl border border-stone-800 max-w-xs hidden sm:block">
              <span className="block text-amber-400 font-bold text-xs uppercase tracking-wider">
                100% Genuine Condiments
              </span>
              <p className="text-xs text-stone-300 mt-1">
                Zero shortcuts. Pure palm oil, locust beans (iru), and traditional crayfish seasonings.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4 Core Pillars */}
      <section className="bg-white border-y border-stone-200 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-red-700">
              Our Non-Negotiables
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-serif mt-1">
              Why Customers Trust Mary Restaurant
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-3">
              <div className="w-12 h-12 bg-red-100 text-red-700 rounded-xl flex items-center justify-center">
                <Flame className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-stone-900 text-lg font-serif">Firewood Smoky Flavour</h3>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                We recreate the legendary party jollof rice flavour that Lagosians love, complete with tender fried dodo.
              </p>
            </div>

            <div className="p-6 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-3">
              <div className="w-12 h-12 bg-red-100 text-red-700 rounded-xl flex items-center justify-center">
                <Utensils className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-stone-900 text-lg font-serif">Generous Portions</h3>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                Nigerian hospitality means feeding well. Our bowls are brimming with protein, thick soup, and hearty swallows.
              </p>
            </div>

            <div className="p-6 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-3">
              <div className="w-12 h-12 bg-red-100 text-red-700 rounded-xl flex items-center justify-center">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-stone-900 text-lg font-serif">Hygienic Packaging</h3>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                Spill-proof, food-grade thermal microwaveable bowls keep your meal hot and pristine during transit.
              </p>
            </div>

            <div className="p-6 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-3">
              <div className="w-12 h-12 bg-red-100 text-red-700 rounded-xl flex items-center justify-center">
                <Heart className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-stone-900 text-lg font-serif">Cooked With Care</h3>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                Every pot is monitored by experienced indigenous chefs with high culinary hygiene and dedication.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Catering & Events Callout */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-stone-900 text-white rounded-3xl p-8 sm:p-12 border border-stone-800 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="space-y-3 max-w-xl">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
              Corporate & Event Catering
            </span>
            <h3 className="text-2xl sm:text-3xl font-bold font-serif">
              Planning a Birthday, Office Meeting, or Wedding?
            </h3>
            <p className="text-stone-300 text-sm leading-relaxed">
              We cater for bulk trays of Jollof rice, Assorted Native Soups, Swallow bars, 
              Small Chops, and Grills. Reach out to discuss custom dietary needs and schedules.
            </p>
          </div>

          <a
            href={`https://wa.me/${whatsappPhone}?text=${encodeURIComponent('Hello Chef Mary! I would like to inquire about event catering and bulk food trays.')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 px-6 rounded-xl flex items-center gap-2 transition-colors text-sm"
          >
            <Phone className="w-4 h-4" />
            <span>Chat on WhatsApp</span>
          </a>
        </div>
      </section>
    </div>
  );
};
