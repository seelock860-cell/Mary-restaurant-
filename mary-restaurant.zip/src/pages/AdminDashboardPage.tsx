import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  ShoppingBag, 
  UtensilsCrossed, 
  Settings, 
  Database, 
  LogOut, 
  CheckCircle, 
  Clock, 
  Truck, 
  XCircle, 
  Building2, 
  Plus, 
  Edit, 
  Trash2, 
  Search, 
  Check, 
  Copy, 
  AlertCircle, 
  RefreshCw,
  Phone,
  Eye,
  DollarSign
} from 'lucide-react';
import { Order, Product, Category, RestaurantSettings, PageRoute, OrderStatus } from '../types';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

interface AdminDashboardPageProps {
  products: Product[];
  categories: Category[];
  onRefreshMenu: () => void;
  setCurrentPage: (page: PageRoute) => void;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({
  products,
  categories,
  onRefreshMenu,
  setCurrentPage,
}) => {
  const { adminUser, adminToken, logout } = useAuth();
  const { formatNaira, settings, setSettings } = useCart();

  // Tab state
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'menu' | 'settings' | 'supabase'>('overview');

  // Orders state
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [orderFilter, setOrderFilter] = useState<string>('all');
  const [orderSearch, setOrderSearch] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Menu item modal state
  const [isEditingProduct, setIsEditingProduct] = useState(false);
  const [productForm, setProductForm] = useState<Partial<Product>>({
    name: '',
    description: '',
    price: 3000,
    image_url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80',
    category_id: 'rice-dishes',
    is_available: true,
  });
  const [editingProductId, setEditingProductId] = useState<string | null>(null);

  // Settings form state
  const [settingsForm, setSettingsForm] = useState<RestaurantSettings | null>(settings);
  const [settingsSaveSuccess, setSettingsSaveSuccess] = useState(false);

  // Supabase test state
  const [supabaseUrl, setSupabaseUrl] = useState(settings?.supabase_url || '');
  const [supabaseKey, setSupabaseKey] = useState('');
  const [supabaseTestResult, setSupabaseTestResult] = useState<{ success: boolean; message: string; hint?: string } | null>(null);
  const [isTestingSupabase, setIsTestingSupabase] = useState(false);
  const [copiedSql, setCopiedSql] = useState(false);

  // Load orders
  const loadOrders = async () => {
    setLoadingOrders(true);
    try {
      const res = await api.getAdminOrders(adminToken || undefined);
      if (res && res.orders) {
        setOrders(res.orders);
      }
    } catch (err) {
      console.error('Failed to load orders', err);
    } finally {
      setLoadingOrders(false);
    }
  };

  useEffect(() => {
    loadOrders();
  }, [adminToken]);

  useEffect(() => {
    if (settings) {
      setSettingsForm(settings);
    }
  }, [settings]);

  // Handle Order Status change
  const handleUpdateOrderStatus = async (orderId: string, status: OrderStatus) => {
    try {
      const res = await api.updateOrderStatus(orderId, status, adminToken || undefined);
      if (res.success && res.order) {
        setOrders((prev) => prev.map((o) => (o.id === orderId ? res.order : o)));
        if (selectedOrder?.id === orderId) {
          setSelectedOrder(res.order);
        }
      }
    } catch (err) {
      alert('Failed to update status');
    }
  };

  // Handle Bank Transfer Payment Verification
  const handleVerifyPayment = async (orderId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'paid' ? 'pending_verification' : 'paid';
    try {
      const res = await api.verifyPayment(orderId, nextStatus, adminToken || undefined);
      if (res.success && res.order) {
        setOrders((prev) => prev.map((o) => (o.id === orderId ? res.order : o)));
        if (selectedOrder?.id === orderId) {
          setSelectedOrder(res.order);
        }
      }
    } catch (err) {
      alert('Failed to update payment status');
    }
  };

  // Handle Product Save (Add or Edit)
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productForm.name || !productForm.price || !productForm.category_id) {
      alert('Please fill name, price, and category.');
      return;
    }

    try {
      if (editingProductId) {
        await api.updateProduct(editingProductId, productForm, adminToken || undefined);
      } else {
        await api.addProduct(productForm, adminToken || undefined);
      }
      setIsEditingProduct(false);
      setEditingProductId(null);
      setProductForm({
        name: '',
        description: '',
        price: 3000,
        image_url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80',
        category_id: 'rice-dishes',
        is_available: true,
      });
      onRefreshMenu();
    } catch (err: any) {
      alert(err.message || 'Failed to save product');
    }
  };

  // Handle Product Delete
  const handleDeleteProduct = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete "${name}" from the menu?`)) return;
    try {
      await api.deleteProduct(id, adminToken || undefined);
      onRefreshMenu();
    } catch (err: any) {
      alert(err.message || 'Failed to delete dish');
    }
  };

  // Handle Settings Save
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settingsForm) return;

    try {
      const res = await api.updateSettings(settingsForm, adminToken || undefined);
      if (res.success && res.settings) {
        setSettings(res.settings);
        setSettingsSaveSuccess(true);
        setTimeout(() => setSettingsSaveSuccess(false), 3000);
      }
    } catch (err: any) {
      alert('Failed to save settings: ' + err.message);
    }
  };

  // Handle Supabase Connection Test
  const handleTestSupabase = async () => {
    if (!supabaseUrl || !supabaseKey) {
      alert('Please enter both Supabase URL and Key');
      return;
    }
    setIsTestingSupabase(true);
    setSupabaseTestResult(null);
    try {
      const result = await api.testSupabase(supabaseUrl, supabaseKey);
      setSupabaseTestResult(result);
    } catch (err: any) {
      setSupabaseTestResult({
        success: false,
        message: err.message || 'Connection failed',
      });
    } finally {
      setIsTestingSupabase(false);
    }
  };

  // Copy Migration SQL helper
  const handleCopySql = () => {
    const sqlScript = `-- MARY RESTAURANT SCHEMA
CREATE TABLE IF NOT EXISTS public.profiles (id UUID PRIMARY KEY REFERENCES auth.users(id), full_name TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer');
CREATE TABLE IF NOT EXISTS public.categories (id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT);
CREATE TABLE IF NOT EXISTS public.products (id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT, price NUMERIC, image_url TEXT, category_id TEXT, is_available BOOLEAN DEFAULT true);
CREATE TABLE IF NOT EXISTS public.orders (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), order_number TEXT UNIQUE, customer_name TEXT, customer_phone TEXT, delivery_address TEXT, delivery_method TEXT, subtotal NUMERIC, delivery_fee NUMERIC, total_amount NUMERIC, order_status TEXT, payment_status TEXT, payment_method TEXT, payment_reference TEXT, created_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE IF NOT EXISTS public.order_items (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), order_id UUID REFERENCES public.orders(id), product_id TEXT, product_name TEXT, unit_price NUMERIC, quantity INTEGER, line_total NUMERIC);
CREATE TABLE IF NOT EXISTS public.restaurant_settings (id INTEGER PRIMARY KEY DEFAULT 1, restaurant_name TEXT, whatsapp_number TEXT, bank_name TEXT, bank_account_name TEXT, bank_account_number TEXT, opening_hours TEXT, delivery_fee NUMERIC);
-- Run in Supabase SQL editor`;
    navigator.clipboard.writeText(sqlScript);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  // Filtered Orders
  const filteredOrders = orders.filter((o) => {
    const matchesFilter =
      orderFilter === 'all' ||
      (orderFilter === 'pending' && o.order_status === 'pending') ||
      (orderFilter === 'confirmed' && o.order_status === 'confirmed') ||
      (orderFilter === 'preparing' && o.order_status === 'preparing') ||
      (orderFilter === 'delivered' && o.order_status === 'delivered') ||
      (orderFilter === 'cancelled' && o.order_status === 'cancelled') ||
      (orderFilter === 'unverified_bank' && o.payment_method === 'bank_transfer' && o.payment_status === 'pending_verification');

    const matchesSearch =
      o.order_number.toLowerCase().includes(orderSearch.toLowerCase()) ||
      o.customer_name.toLowerCase().includes(orderSearch.toLowerCase()) ||
      o.customer_phone.includes(orderSearch);

    return matchesFilter && matchesSearch;
  });

  // KPI Metrics Calculation
  const totalOrdersCount = orders.length;
  const newPendingOrders = orders.filter((o) => o.order_status === 'pending').length;
  const preparingOrders = orders.filter((o) => o.order_status === 'preparing' || o.order_status === 'confirmed').length;
  const deliveredOrders = orders.filter((o) => o.order_status === 'delivered').length;
  const cancelledOrders = orders.filter((o) => o.order_status === 'cancelled').length;
  const pendingBankTransfers = orders.filter(
    (o) => o.payment_method === 'bank_transfer' && o.payment_status === 'pending_verification'
  ).length;

  // Verified sales: sum of total_amount ONLY for orders where payment_status === 'paid'
  const verifiedSalesTotal = orders
    .filter((o) => o.payment_status === 'paid')
    .reduce((sum, o) => sum + o.total_amount, 0);

  const curatedPhotos = [
    { label: 'Party Jollof Rice', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80' },
    { label: 'Fried Rice & Chicken', url: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=800&auto=format&fit=crop&q=80' },
    { label: 'Egusi & Pounded Yam', url: 'https://images.unsplash.com/photo-1543339308-43e59d6b73a6?w=800&auto=format&fit=crop&q=80' },
    { label: 'Ogbono Soup & Eba', url: 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=800&auto=format&fit=crop&q=80' },
    { label: 'Fresh Okra Seafood', url: 'https://images.unsplash.com/photo-1547592180-85f173990554?w=800&auto=format&fit=crop&q=80' },
    { label: 'Efo Riro Vegetable', url: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=800&auto=format&fit=crop&q=80' },
    { label: 'Amala Abula Ewedu', url: 'https://images.unsplash.com/photo-1514944298352-78d1209b5557?w=800&auto=format&fit=crop&q=80' },
    { label: 'Flame-Grilled Chicken', url: 'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?w=800&auto=format&fit=crop&q=80' },
    { label: 'Crispy Peppered Chicken', url: 'https://images.unsplash.com/photo-1562967914-608f82629710?w=800&auto=format&fit=crop&q=80' },
    { label: 'Beans & Dodo (Aganyin)', url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800&auto=format&fit=crop&q=80' },
    { label: 'Fried Sweet Plantain', url: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=800&auto=format&fit=crop&q=80' },
    { label: 'Chilled Chapman', url: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=800&auto=format&fit=crop&q=80' },
  ];

  return (
    <div className="min-h-screen bg-stone-100/60 pb-20">
      {/* Admin Top Navigation */}
      <div className="bg-stone-900 text-white border-b border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-red-700 text-white rounded-lg flex items-center justify-center font-serif font-black text-lg">
              M
            </div>
            <div>
              <span className="font-serif font-bold text-base text-stone-100">
                MARY RESTAURANT ADMIN
              </span>
              <span className="text-[10px] text-red-400 block -mt-0.5 font-medium">
                Signed in as {adminUser?.username || 'Mary'} (Administrator)
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setCurrentPage('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="text-xs text-stone-300 hover:text-white px-3 py-1.5 rounded-lg border border-stone-700 hover:bg-stone-800 transition-colors"
            >
              View Live Storefront
            </button>

            <button
              onClick={() => {
                logout();
                setCurrentPage('home');
              }}
              className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-900/60 hover:bg-red-950/40 transition-colors"
              title="Logout"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
        
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-stone-200">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-colors ${
              activeTab === 'overview'
                ? 'bg-red-700 text-white shadow-sm'
                : 'bg-white hover:bg-stone-50 text-stone-700 border border-stone-200'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Dashboard Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-colors ${
              activeTab === 'orders'
                ? 'bg-red-700 text-white shadow-sm'
                : 'bg-white hover:bg-stone-50 text-stone-700 border border-stone-200'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Customer Orders ({orders.length})</span>
            {pendingBankTransfers > 0 && (
              <span className="bg-amber-400 text-amber-950 text-[10px] px-1.5 py-0.2 rounded-full font-black animate-pulse">
                {pendingBankTransfers} bank
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('menu')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-colors ${
              activeTab === 'menu'
                ? 'bg-red-700 text-white shadow-sm'
                : 'bg-white hover:bg-stone-50 text-stone-700 border border-stone-200'
            }`}
          >
            <UtensilsCrossed className="w-4 h-4" />
            <span>Menu & Pricing ({products.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-colors ${
              activeTab === 'settings'
                ? 'bg-red-700 text-white shadow-sm'
                : 'bg-white hover:bg-stone-50 text-stone-700 border border-stone-200'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Restaurant Settings</span>
          </button>

          <button
            onClick={() => setActiveTab('supabase')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm whitespace-nowrap transition-colors ${
              activeTab === 'supabase'
                ? 'bg-red-700 text-white shadow-sm'
                : 'bg-white hover:bg-stone-50 text-stone-700 border border-stone-200'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Supabase Database & SQL</span>
          </button>
        </div>

        {/* 1. OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-8 animate-fadeIn">
            {/* KPI Stat Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-xs text-stone-500 uppercase font-semibold">Total Orders</span>
                <span className="text-2xl font-black text-stone-900 block font-mono">{totalOrdersCount}</span>
                <span className="text-[11px] text-stone-400">All recorded</span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-xs text-stone-500 uppercase font-semibold">New Pending</span>
                <span className="text-2xl font-black text-amber-600 block font-mono">{newPendingOrders}</span>
                <span className="text-[11px] text-amber-700">Awaiting dispatch</span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-xs text-stone-500 uppercase font-semibold">In Kitchen</span>
                <span className="text-2xl font-black text-blue-600 block font-mono">{preparingOrders}</span>
                <span className="text-[11px] text-blue-700">Cooking / Confirmed</span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-xs text-stone-500 uppercase font-semibold">Delivered</span>
                <span className="text-2xl font-black text-emerald-600 block font-mono">{deliveredOrders}</span>
                <span className="text-[11px] text-emerald-700">Fulfilled orders</span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-xs text-stone-500 uppercase font-semibold">Cancelled</span>
                <span className="text-2xl font-black text-stone-400 block font-mono">{cancelledOrders}</span>
                <span className="text-[11px] text-stone-400">Voided</span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-stone-200/90 shadow-sm space-y-1">
                <span className="text-xs text-stone-500 uppercase font-semibold">Pending Transfer</span>
                <span className="text-2xl font-black text-red-600 block font-mono">{pendingBankTransfers}</span>
                <span className="text-[11px] text-red-600">Needs verification</span>
              </div>
            </div>

            {/* Total Verified Sales Banner */}
            <div className="bg-gradient-to-r from-stone-900 via-stone-950 to-stone-900 text-white rounded-3xl p-6 sm:p-8 border border-stone-800 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-6">
              <div className="space-y-1 text-center sm:text-left">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  Total Verified Sales (Naira)
                </span>
                <h3 className="text-3xl sm:text-4xl font-mono font-black text-white">
                  {formatNaira(verifiedSalesTotal)}
                </h3>
                <p className="text-xs text-stone-400">
                  Calculated strictly from orders with verified payment status.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    setOrderFilter('unverified_bank');
                    setActiveTab('orders');
                  }}
                  className="bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs py-2.5 px-4 rounded-xl transition-colors shadow"
                >
                  Verify Bank Transfers ({pendingBankTransfers})
                </button>
                <button
                  onClick={() => {
                    setIsEditingProduct(true);
                    setEditingProductId(null);
                    setActiveTab('menu');
                  }}
                  className="bg-red-700 hover:bg-red-800 text-white font-bold text-xs py-2.5 px-4 rounded-xl transition-colors shadow"
                >
                  + Add New Meal
                </button>
              </div>
            </div>

            {/* Quick Recent Orders */}
            <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                <h3 className="font-bold text-stone-900 font-serif text-base">
                  Recent Incoming Orders
                </h3>
                <button
                  onClick={() => setActiveTab('orders')}
                  className="text-xs font-bold text-red-700 hover:text-red-800"
                >
                  View All Orders →
                </button>
              </div>

              <div className="divide-y divide-stone-100">
                {orders.slice(0, 5).map((order) => (
                  <div key={order.id} className="py-3 flex items-center justify-between gap-4 text-xs">
                    <div>
                      <span className="font-mono font-bold text-stone-900 block">
                        {order.order_number}
                      </span>
                      <span className="text-stone-500">
                        {order.customer_name} ({order.customer_phone}) · {order.items.length} dishes
                      </span>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-bold text-stone-900">
                        {formatNaira(order.total_amount)}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          order.payment_status === 'paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {order.payment_status}
                      </span>
                      <button
                        onClick={() => {
                          setSelectedOrder(order);
                          setActiveTab('orders');
                        }}
                        className="p-1 text-stone-400 hover:text-stone-700"
                        title="View details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 2. ORDERS MANAGEMENT TAB */}
        {activeTab === 'orders' && (
          <div className="space-y-6 animate-fadeIn">
            {/* Toolbar: Filters and Search */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
              {/* Search */}
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                <input
                  type="text"
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                  placeholder="Search by Order #, customer name, or phone..."
                  className="w-full pl-10 pr-4 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              {/* Status Filters */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {[
                  { id: 'all', label: 'All' },
                  { id: 'unverified_bank', label: 'Pending Bank Transfers' },
                  { id: 'pending', label: 'Pending' },
                  { id: 'confirmed', label: 'Confirmed' },
                  { id: 'preparing', label: 'Preparing' },
                  { id: 'delivered', label: 'Delivered' },
                  { id: 'cancelled', label: 'Cancelled' },
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setOrderFilter(f.id)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
                      orderFilter === f.id
                        ? 'bg-red-700 text-white shadow-sm'
                        : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>

              <button
                onClick={loadOrders}
                className="p-2 text-stone-500 hover:text-stone-900 border border-stone-200 rounded-xl hover:bg-stone-50"
                title="Refresh orders"
              >
                <RefreshCw className={`w-4 h-4 ${loadingOrders ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {/* Orders Table */}
            <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 uppercase tracking-wider font-bold">
                    <tr>
                      <th className="py-3.5 px-4">Order Ref</th>
                      <th className="py-3.5 px-4">Customer Details</th>
                      <th className="py-3.5 px-4">Delivery Method</th>
                      <th className="py-3.5 px-4">Total (₦)</th>
                      <th className="py-3.5 px-4">Payment Status</th>
                      <th className="py-3.5 px-4">Order Status</th>
                      <th className="py-3.5 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {filteredOrders.length > 0 ? (
                      filteredOrders.map((order) => (
                        <tr key={order.id} className="hover:bg-stone-50/70 transition-colors">
                          <td className="py-3.5 px-4 font-mono font-bold text-stone-900">
                            {order.order_number}
                            <span className="block text-[10px] text-stone-400 font-sans font-normal">
                              {new Date(order.created_at).toLocaleDateString()}
                            </span>
                          </td>

                          <td className="py-3.5 px-4">
                            <span className="font-bold text-stone-900 block">{order.customer_name}</span>
                            <span className="text-stone-500 block">{order.customer_phone}</span>
                          </td>

                          <td className="py-3.5 px-4">
                            <span className="capitalize font-semibold text-stone-800">
                              {order.delivery_method}
                            </span>
                            <span className="block text-[10px] text-stone-500 line-clamp-1 max-w-[150px]">
                              {order.delivery_address}
                            </span>
                          </td>

                          <td className="py-3.5 px-4 font-extrabold text-stone-900">
                            {formatNaira(order.total_amount)}
                          </td>

                          <td className="py-3.5 px-4">
                            <div className="space-y-1">
                              <span
                                className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                                  order.payment_status === 'paid'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : order.payment_status === 'pending_verification'
                                    ? 'bg-amber-100 text-amber-800'
                                    : 'bg-stone-100 text-stone-600'
                                }`}
                              >
                                {order.payment_status}
                              </span>
                              <span className="block text-[10px] text-stone-400">
                                {order.payment_method === 'bank_transfer' ? 'Bank Transfer' : 'Online'}
                              </span>
                            </div>
                          </td>

                          <td className="py-3.5 px-4">
                            <select
                              value={order.order_status}
                              onChange={(e) => handleUpdateOrderStatus(order.id, e.target.value as OrderStatus)}
                              className="text-xs bg-stone-50 border border-stone-200 rounded-lg p-1 font-semibold text-stone-800 focus:outline-none focus:ring-1 focus:ring-red-600"
                            >
                              <option value="pending">Pending</option>
                              <option value="confirmed">Confirmed</option>
                              <option value="preparing">Preparing</option>
                              <option value="out_for_delivery">Out for Delivery</option>
                              <option value="delivered">Delivered</option>
                              <option value="cancelled">Cancelled</option>
                            </select>
                          </td>

                          <td className="py-3.5 px-4 text-right space-x-2">
                            {order.payment_method === 'bank_transfer' && (
                              <button
                                onClick={() => handleVerifyPayment(order.id, order.payment_status)}
                                className={`text-[11px] font-bold py-1 px-2.5 rounded-lg border transition-colors ${
                                  order.payment_status === 'paid'
                                    ? 'bg-stone-100 text-stone-600 border-stone-200 hover:bg-stone-200'
                                    : 'bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700'
                                }`}
                              >
                                {order.payment_status === 'paid' ? 'Mark Unpaid' : 'Verify Transfer'}
                              </button>
                            )}

                            <button
                              onClick={() => setSelectedOrder(order)}
                              className="text-xs text-stone-600 hover:text-stone-900 border border-stone-200 bg-white hover:bg-stone-50 px-2 py-1 rounded-lg"
                            >
                              View
                            </button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-stone-400">
                          No orders found matching your criteria.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* 3. MENU & PRICING MANAGER TAB */}
        {activeTab === 'menu' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold font-serif text-stone-900">
                  Nigerian Food Dishes ({products.length})
                </h3>
                <p className="text-xs text-stone-500">
                  Add, edit, delete dishes, mark availability, and set prices in Naira.
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingProductId(null);
                  setProductForm({
                    name: '',
                    description: '',
                    price: 3500,
                    image_url: curatedPhotos[0].url,
                    category_id: categories[0]?.id || 'rice-dishes',
                    is_available: true,
                  });
                  setIsEditingProduct(true);
                }}
                className="inline-flex items-center gap-1.5 bg-red-700 hover:bg-red-800 text-white font-bold text-xs sm:text-sm py-2.5 px-4 rounded-xl shadow transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Food Dish</span>
              </button>
            </div>

            {/* Menu Items Table / Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {products.map((product) => {
                const category = categories.find((c) => c.id === product.category_id);
                return (
                  <div
                    key={product.id}
                    className="bg-white rounded-2xl border border-stone-200 p-4 shadow-sm flex gap-4 items-center justify-between"
                  >
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className="w-16 h-16 rounded-xl object-cover shrink-0 border border-stone-200"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src =
                          'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80';
                      }}
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-stone-400 uppercase truncate">
                          {category?.name || 'Dish'}
                        </span>
                        <span
                          className={`w-2 h-2 rounded-full ${
                            product.is_available ? 'bg-emerald-500' : 'bg-red-500'
                          }`}
                        />
                      </div>
                      <h4 className="font-bold text-sm text-stone-900 truncate font-serif">
                        {product.name}
                      </h4>
                      <span className="text-xs font-black text-red-700">
                        {formatNaira(product.price)}
                      </span>
                    </div>

                    <div className="flex flex-col gap-1.5 shrink-0">
                      <button
                        onClick={() => {
                          setEditingProductId(product.id);
                          setProductForm({ ...product });
                          setIsEditingProduct(true);
                        }}
                        className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-lg"
                        title="Edit Dish"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteProduct(product.id, product.name)}
                        className="p-1.5 text-stone-400 hover:text-red-700 hover:bg-red-50 rounded-lg"
                        title="Delete Dish"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 4. RESTAURANT SETTINGS TAB */}
        {activeTab === 'settings' && settingsForm && (
          <div className="max-w-3xl bg-white rounded-3xl border border-stone-200 p-8 shadow-sm space-y-6 animate-fadeIn">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-red-700">Storefront Config</span>
              <h3 className="text-2xl font-bold font-serif text-stone-900">
                Restaurant Contact & Bank Details
              </h3>
              <p className="text-xs text-stone-500 mt-1">
                These details are displayed dynamically at checkout and on customer order confirmation.
              </p>
            </div>

            {settingsSaveSuccess && (
              <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>Restaurant settings updated successfully!</span>
              </div>
            )}

            <form onSubmit={handleSaveSettings} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                    Restaurant Brand Name
                  </label>
                  <input
                    type="text"
                    required
                    value={settingsForm.restaurant_name}
                    onChange={(e) => setSettingsForm({ ...settingsForm, restaurant_name: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                    WhatsApp Number (International format e.g. 2349024971419)
                  </label>
                  <input
                    type="text"
                    required
                    value={settingsForm.whatsapp_number}
                    onChange={(e) => setSettingsForm({ ...settingsForm, whatsapp_number: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                    Local Phone Display (e.g. 09024971419)
                  </label>
                  <input
                    type="text"
                    required
                    value={settingsForm.phone_display}
                    onChange={(e) => setSettingsForm({ ...settingsForm, phone_display: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                    Delivery Fee in Naira (₦)
                  </label>
                  <input
                    type="number"
                    required
                    value={settingsForm.delivery_fee}
                    onChange={(e) => setSettingsForm({ ...settingsForm, delivery_fee: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm"
                  />
                </div>
              </div>

              {/* Bank Transfer Details Section */}
              <div className="pt-4 border-t border-stone-100 space-y-4">
                <h4 className="text-sm font-bold text-stone-900 font-serif flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-red-700" />
                  <span>Direct Bank Transfer Verification Credentials</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                      Bank Name
                    </label>
                    <input
                      type="text"
                      required
                      value={settingsForm.bank_name}
                      onChange={(e) => setSettingsForm({ ...settingsForm, bank_name: e.target.value })}
                      placeholder="Zenith Bank"
                      className="w-full px-3.5 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                      Account Name
                    </label>
                    <input
                      type="text"
                      required
                      value={settingsForm.bank_account_name}
                      onChange={(e) => setSettingsForm({ ...settingsForm, bank_account_name: e.target.value })}
                      placeholder="MARY RESTAURANT ENTERPRISES"
                      className="w-full px-3.5 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                      Account Number (10 digits)
                    </label>
                    <input
                      type="text"
                      required
                      value={settingsForm.bank_account_number}
                      onChange={(e) => setSettingsForm({ ...settingsForm, bank_account_number: e.target.value })}
                      placeholder="1018944521"
                      className="w-full px-3.5 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm font-mono font-bold"
                    />
                  </div>
                </div>
              </div>

              {/* Location & Opening Hours */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                    Opening Hours
                  </label>
                  <input
                    type="text"
                    required
                    value={settingsForm.opening_hours}
                    onChange={(e) => setSettingsForm({ ...settingsForm, opening_hours: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">
                    Physical Address
                  </label>
                  <input
                    type="text"
                    required
                    value={settingsForm.physical_address}
                    onChange={(e) => setSettingsForm({ ...settingsForm, physical_address: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-stone-100 flex justify-end">
                <button
                  type="submit"
                  className="bg-red-700 hover:bg-red-800 text-white font-bold py-3 px-6 rounded-xl shadow text-sm transition-colors"
                >
                  Save Restaurant Settings
                </button>
              </div>
            </form>
          </div>
        )}

        {/* 5. SUPABASE DATABASE TAB */}
        {activeTab === 'supabase' && (
          <div className="max-w-4xl bg-white rounded-3xl border border-stone-200 p-8 shadow-sm space-y-8 animate-fadeIn">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-red-700">Database & Security</span>
              <h3 className="text-2xl font-bold font-serif text-stone-900">
                Supabase PostgreSQL Configuration
              </h3>
              <p className="text-xs text-stone-600 mt-1">
                Configure your Supabase project credentials for persistent PostgreSQL storage and authentication.
              </p>
            </div>

            {/* Connection Test Box */}
            <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200 space-y-4">
              <h4 className="font-bold text-sm text-stone-900 font-serif">
                1. Test Live Supabase Connection
              </h4>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Supabase Project URL
                  </label>
                  <input
                    type="url"
                    value={supabaseUrl}
                    onChange={(e) => setSupabaseUrl(e.target.value)}
                    placeholder="https://xyzabcdefg.supabase.co"
                    className="w-full px-3.5 py-2 bg-white border border-stone-300 rounded-xl text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Supabase Publishable / Service Key
                  </label>
                  <input
                    type="password"
                    value={supabaseKey}
                    onChange={(e) => setSupabaseKey(e.target.value)}
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                    className="w-full px-3.5 py-2 bg-white border border-stone-300 rounded-xl text-xs font-mono"
                  />
                  <span className="text-[11px] text-stone-500 mt-1 block">
                    Never expose service role key to browser clients. Verified server-side.
                  </span>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={handleTestSupabase}
                    disabled={isTestingSupabase}
                    className="bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs py-2.5 px-5 rounded-xl transition-colors flex items-center gap-2"
                  >
                    {isTestingSupabase ? (
                      <>
                        <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Testing Connection...</span>
                      </>
                    ) : (
                      <span>Test Supabase Connection</span>
                    )}
                  </button>
                </div>
              </div>

              {supabaseTestResult && (
                <div
                  className={`p-4 rounded-xl text-xs space-y-1 ${
                    supabaseTestResult.success
                      ? 'bg-emerald-50 border border-emerald-200 text-emerald-900'
                      : 'bg-red-50 border border-red-200 text-red-900'
                  }`}
                >
                  <div className="font-bold flex items-center gap-1.5">
                    {supabaseTestResult.success ? (
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-red-600" />
                    )}
                    <span>{supabaseTestResult.message}</span>
                  </div>
                  {supabaseTestResult.hint && (
                    <p className="text-stone-600">{supabaseTestResult.hint}</p>
                  )}
                </div>
              )}
            </div>

            {/* SQL Migration Script Box */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-stone-900 font-serif">
                    2. Supabase SQL Migrations & Schema
                  </h4>
                  <p className="text-xs text-stone-500">
                    Tables created: profiles, categories, products, orders, order_items, payments, restaurant_settings.
                  </p>
                </div>

                <button
                  onClick={handleCopySql}
                  className="inline-flex items-center gap-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold py-2 px-3.5 rounded-xl border border-stone-300 transition-colors"
                >
                  {copiedSql ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Copied Migration SQL!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Full SQL Schema</span>
                    </>
                  )}
                </button>
              </div>

              <div className="bg-stone-900 text-stone-200 p-4 rounded-2xl font-mono text-xs overflow-x-auto max-h-60 border border-stone-800">
                <pre>{`-- Available in /supabase/migrations/20261027_init_mary_restaurant.sql
-- 1. profiles table (RLS enabled)
-- 2. categories table (RLS enabled)
-- 3. products table (RLS enabled)
-- 4. orders table (RLS enabled)
-- 5. order_items table (RLS enabled)
-- 6. payments table (RLS enabled)
-- 7. restaurant_settings table (RLS enabled)
-- Full SQL file ready to run directly in Supabase SQL Editor.`}</pre>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* MODAL: View Order Details */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-stone-200 space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <span className="text-xs uppercase font-bold text-red-700">Order Information</span>
                <h3 className="text-xl font-mono font-black text-stone-900">
                  {selectedOrder.order_number}
                </h3>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="text-stone-400 hover:text-stone-700 p-2 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-stone-400 block uppercase text-[10px]">Customer</span>
                <strong className="text-stone-900 text-sm">{selectedOrder.customer_name}</strong>
                <p className="text-stone-600">{selectedOrder.customer_phone}</p>
              </div>

              <div>
                <span className="text-stone-400 block uppercase text-[10px]">Fulfilment</span>
                <strong className="text-stone-900 capitalize text-sm">{selectedOrder.delivery_method}</strong>
                <p className="text-stone-600">{selectedOrder.delivery_address}</p>
              </div>

              {selectedOrder.delivery_instructions && (
                <div className="col-span-2 bg-stone-50 p-2.5 rounded-lg border border-stone-200">
                  <span className="text-[10px] uppercase font-bold text-stone-500">Delivery Instructions:</span>
                  <p className="text-stone-800 italic">{selectedOrder.delivery_instructions}</p>
                </div>
              )}

              <div>
                <span className="text-stone-400 block uppercase text-[10px]">Payment Method</span>
                <span className="font-semibold text-stone-900 capitalize">
                  {selectedOrder.payment_method === 'bank_transfer' ? 'Bank Transfer' : 'Online'}
                </span>
                {selectedOrder.payment_reference && (
                  <p className="text-[11px] text-amber-800">Ref: {selectedOrder.payment_reference}</p>
                )}
              </div>

              <div>
                <span className="text-stone-400 block uppercase text-[10px]">Payment Status</span>
                <span
                  className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                    selectedOrder.payment_status === 'paid'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {selectedOrder.payment_status}
                </span>
              </div>
            </div>

            {/* Dishes in order */}
            <div>
              <span className="text-xs uppercase font-bold text-stone-500 mb-2 block">
                Order Items ({selectedOrder.items.length})
              </span>
              <div className="divide-y divide-stone-100 border border-stone-200 rounded-xl overflow-hidden">
                {selectedOrder.items.map((item, i) => (
                  <div key={i} className="p-2.5 flex items-center justify-between text-xs bg-stone-50">
                    <span>{item.quantity}x {item.product_name}</span>
                    <span className="font-bold">{formatNaira(item.line_total)}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-stone-100 flex justify-between text-sm font-black">
              <span>Grand Total</span>
              <span className="text-red-700 text-lg">{formatNaira(selectedOrder.total_amount)}</span>
            </div>

            {/* Actions in Modal */}
            <div className="pt-3 border-t border-stone-100 flex items-center justify-between gap-3">
              {selectedOrder.payment_method === 'bank_transfer' && (
                <button
                  onClick={() => handleVerifyPayment(selectedOrder.id, selectedOrder.payment_status)}
                  className={`text-xs font-bold py-2 px-4 rounded-xl border transition-colors ${
                    selectedOrder.payment_status === 'paid'
                      ? 'bg-stone-100 text-stone-700 border-stone-200 hover:bg-stone-200'
                      : 'bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700'
                  }`}
                >
                  {selectedOrder.payment_status === 'paid' ? 'Mark As Unverified' : '✓ Verify Bank Transfer'}
                </button>
              )}

              <a
                href={`https://wa.me/${selectedOrder.customer_phone.replace(/\D/g, '')}?text=${encodeURIComponent(`Hello ${selectedOrder.customer_name}, this is Mary Restaurant regarding your order ${selectedOrder.order_number}.`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold py-2 px-3 rounded-xl hover:bg-emerald-100"
              >
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span>WhatsApp Customer</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Add / Edit Product */}
      {isEditingProduct && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-stone-200 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="text-lg font-bold font-serif text-stone-900">
                {editingProductId ? 'Edit Food Dish' : 'Add New Nigerian Meal'}
              </h3>
              <button
                onClick={() => setIsEditingProduct(false)}
                className="text-stone-400 hover:text-stone-700 p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 uppercase mb-1">
                  Food Name *
                </label>
                <input
                  type="text"
                  required
                  value={productForm.name}
                  onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                  placeholder="e.g. Asun Spicy Goat Meat"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-700 uppercase mb-1">
                    Price in Naira (₦) *
                  </label>
                  <input
                    type="number"
                    required
                    value={productForm.price}
                    onChange={(e) => setProductForm({ ...productForm, price: Number(e.target.value) })}
                    placeholder="3500"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 uppercase mb-1">
                    Category *
                  </label>
                  <select
                    value={productForm.category_id}
                    onChange={(e) => setProductForm({ ...productForm, category_id: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 uppercase mb-1">
                  Description *
                </label>
                <textarea
                  required
                  rows={3}
                  value={productForm.description}
                  onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                  placeholder="Ingredients, seasonings, sides served with..."
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 uppercase mb-1">
                  Food Photograph URL *
                </label>
                <input
                  type="url"
                  required
                  value={productForm.image_url}
                  onChange={(e) => setProductForm({ ...productForm, image_url: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs"
                />
              </div>

              {/* Quick Photo Selector */}
              <div>
                <span className="block font-semibold text-stone-500 mb-1">Or choose an authentic dish photo:</span>
                <div className="grid grid-cols-4 gap-2">
                  {curatedPhotos.slice(0, 8).map((photo, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setProductForm({ ...productForm, image_url: photo.url })}
                      className={`relative aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                        productForm.image_url === photo.url ? 'border-red-600 scale-95' : 'border-stone-200'
                      }`}
                      title={photo.label}
                    >
                      <img src={photo.url} alt={photo.label} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="availCheck"
                  checked={productForm.is_available}
                  onChange={(e) => setProductForm({ ...productForm, is_available: e.target.checked })}
                  className="w-4 h-4 text-red-600 rounded"
                />
                <label htmlFor="availCheck" className="font-bold text-stone-800">
                  Mark as Available in Restaurant
                </label>
              </div>

              <div className="pt-3 border-t border-stone-100 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsEditingProduct(false)}
                  className="px-4 py-2 border border-stone-300 rounded-xl text-stone-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-700 hover:bg-red-800 text-white font-bold rounded-xl"
                >
                  {editingProductId ? 'Update Dish' : 'Create Dish'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
