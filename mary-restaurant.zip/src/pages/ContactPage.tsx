import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  MessageCircle, 
  Send, 
  CheckCircle2, 
  HelpCircle 
} from 'lucide-react';
import { useCart } from '../context/CartContext';

export const ContactPage: React.FC = () => {
  const { settings } = useCart();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const whatsappPhone = settings?.whatsapp_number || '2349024971419';
  const displayPhone = settings?.phone_display || '09024971419';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !message) return;
    setSubmitted(true);
    setTimeout(() => {
      setName('');
      setPhone('');
      setMessage('');
      setSubmitted(false);
    }, 4000);
  };

  const faqs = [
    {
      q: 'What areas in Lagos do you deliver to?',
      a: 'We deliver to Victoria Island, Ikoyi, Lekki Phase 1, Ajah, Ikeja, Surulere, Yaba, Maryland, and surrounding Lagos environs via our dispatch partners.',
    },
    {
      q: 'How long does delivery take?',
      a: 'Most hot meals are dispatched within 25–40 minutes of confirmation. For large catering trays or bulk orders, we suggest booking 3–4 hours in advance.',
    },
    {
      q: 'Can I pay via Bank Transfer?',
      a: 'Yes! We support direct bank transfers to our official Zenith Bank account. Our administrator verifies payments and updates your order tracking in real-time.',
    },
    {
      q: 'Can I pick up my food personally?',
      a: 'Absolutely. Choose "Self Pickup" during checkout with zero delivery fee and collect directly from our Victoria Island kitchen.',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-wider text-red-700">
          We Are Here For You
        </span>
        <h1 className="text-3xl sm:text-5xl font-black text-stone-950 font-serif">
          Get in Touch With Mary Restaurant
        </h1>
        <p className="text-sm sm:text-base text-stone-600 leading-relaxed">
          Have an inquiry regarding an order, corporate lunch bookings, or custom meal requests? 
          Reach out via WhatsApp, phone, or send us a message below.
        </p>
      </div>

      {/* Contact Channels Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* WhatsApp & Call */}
        <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-sm space-y-4">
          <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
            <MessageCircle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-stone-900 font-serif text-lg">WhatsApp & Calls</h3>
            <p className="text-xs text-stone-500 mt-1">Instant replies during operational hours</p>
          </div>
          <div className="pt-2">
            <a
              href={`https://wa.me/${whatsappPhone}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-red-700 hover:text-red-800 font-extrabold text-sm block"
            >
              {displayPhone}
            </a>
            <span className="text-[11px] text-stone-400 block mt-0.5">International: +{whatsappPhone}</span>
          </div>
          <a
            href={`https://wa.me/${whatsappPhone}?text=${encodeURIComponent('Hello Mary Restaurant! I have an enquiry.')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded-xl text-xs transition-colors w-full justify-center"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Chat on WhatsApp</span>
          </a>
        </div>

        {/* Location */}
        <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-sm space-y-4">
          <div className="w-12 h-12 bg-red-50 text-red-700 rounded-xl flex items-center justify-center">
            <MapPin className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-stone-900 font-serif text-lg">Kitchen & Pickup Hub</h3>
            <p className="text-xs text-stone-500 mt-1">Visit for dining or pick up takeaway</p>
          </div>
          <p className="text-xs text-stone-700 font-medium leading-relaxed">
            {settings?.physical_address || '14 Adeola Odeku Street, Victoria Island, Lagos, Nigeria'}
          </p>
          <span className="text-[11px] text-stone-400 block">
            Easily accessible with secure customer parking.
          </span>
        </div>

        {/* Operating Hours */}
        <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-sm space-y-4">
          <div className="w-12 h-12 bg-stone-100 text-stone-800 rounded-xl flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-stone-900 font-serif text-lg">Opening Hours</h3>
            <p className="text-xs text-stone-500 mt-1">Serving hot food 7 days a week</p>
          </div>
          <p className="text-xs text-stone-700 font-medium leading-relaxed">
            {settings?.opening_hours || 'Monday - Sunday: 8:00 AM - 10:00 PM'}
          </p>
          <span className="text-[11px] text-emerald-700 font-semibold block">
            Kitchen dispatch active right now!
          </span>
        </div>
      </div>

      {/* Contact Form & FAQ */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        {/* Form */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-stone-200 p-8 shadow-sm space-y-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-red-700">Send an Enquiry</span>
            <h2 className="text-2xl font-bold text-stone-950 font-serif">Leave a Message</h2>
            <p className="text-xs sm:text-sm text-stone-600 mt-1">
              Fill in your details and our customer representative will respond shortly.
            </p>
          </div>

          {submitted ? (
            <div className="p-6 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
              <h4 className="font-bold text-emerald-950 text-base">Message Sent Successfully!</h4>
              <p className="text-xs text-emerald-800">
                Thank you for reaching out to Mary Restaurant. We will attend to your request promptly.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Folake Alabi"
                    className="w-full px-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 08023456789"
                    className="w-full px-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Your Message or Special Request *
                </label>
                <textarea
                  required
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Tell us what you need, order feedback, or questions about catering..."
                  className="w-full px-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <button
                type="submit"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-red-700 hover:bg-red-800 text-white font-bold py-3 px-6 rounded-xl shadow-md transition-colors text-sm"
              >
                <Send className="w-4 h-4" />
                <span>Submit Message</span>
              </button>
            </form>
          )}
        </div>

        {/* FAQs */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-red-700">
            <HelpCircle className="w-4 h-4" />
            <span>Frequently Asked Questions</span>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <div
                key={i}
                className="bg-white p-5 rounded-2xl border border-stone-200/80 shadow-sm space-y-2"
              >
                <h4 className="font-bold text-stone-900 text-sm font-serif">{faq.q}</h4>
                <p className="text-xs text-stone-600 leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
