import React from 'react';
import { 
  ArrowRight, 
  Flame, 
  Clock, 
  ShieldCheck, 
  Truck, 
  Star, 
  Phone, 
  MapPin, 
  Sparkles,
  UtensilsCrossed 
} from 'lucide-react';
import { Product, Category, PageRoute } from '../types';
import { FoodCard } from '../components/FoodCard';
import { useCart } from '../context/CartContext';

interface HomePageProps {
  products: Product[];
  categories: Category[];
  setCurrentPage: (page: PageRoute) => void;
  onSelectProduct: (product: Product) => void;
  setSelectedCategory: (catId: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  products,
  categories,
  setCurrentPage,
  onSelectProduct,
  setSelectedCategory,
}) => {
  const { settings, formatNaira } = useCart();

  const featuredProducts = products.filter((p) =>
    ['jollof-rice-chicken', 'egusi-pounded-yam', 'special-fried-rice', 'amala-ewedu-gbegiri'].includes(p.id)
  );

  const popularMeals = products.filter((p) =>
    ['peppered-fried-chicken', 'beans-plantain', 'okra-soup-fufu', 'nigerian-chapman'].includes(p.id)
  );

  const testimonials = [
    {
      name: 'Oluwaseun Adeleke',
      location: 'Victoria Island, Lagos',
      rating: 5,
      comment:
        'The party jollof tastes exactly like genuine Nigerian wedding jollof with that rich firewood aroma! Packed hot and arrived right on time.',
      dish: 'Smoky Party Jollof & Chicken',
    },
    {
      name: 'Chioma Nnamdi',
      location: 'Lekki Phase 1',
      rating: 5,
      comment:
        'Their Egusi soup and soft pounded yam took me straight home. Generous stockfish and goat meat cuts. Mary Restaurant never disappoints!',
      dish: 'Egusi Soup with Pounded Yam',
    },
    {
      name: 'Alhaji Ibrahim Danladi',
      location: 'Ikoyi, Lagos',
      rating: 5,
      comment:
        'Cleanest packaging in Lagos. The peppered chicken is fiery and juicy, and transferring money directly via Zenith Bank was seamless.',
      dish: 'Crispy Peppered Chicken',
    },
  ];

  const whatsappPhone = settings?.whatsapp_number || '2349024971419';
  const displayPhone = settings?.phone_display || '09024971419';

  return (
    <div className="space-y-16 sm:space-y-24 pb-16">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#f7f2ea] to-[#faf7f2] border-b border-stone-200/60 pt-8 sm:pt-14 pb-16 sm:pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Headline & CTA */}
            <div className="lg:col-span-7 space-y-6 sm:space-y-8 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold uppercase tracking-wider text-red-700 bg-red-100/70 px-3.5 py-1.5 rounded-full">
                <Flame className="w-4 h-4 text-red-600" />
                <span>Authentic Taste of Nigeria in Every Bite</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-stone-950 font-serif tracking-tight leading-[1.12]">
                Rich Nigerian Meals, <br className="hidden sm:inline" />
                <span className="text-red-700">Prepared Fresh</span> for Your Table.
              </h1>

              <p className="text-base sm:text-lg text-stone-700 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
                Enjoy smoky firewood Party Jollof, rich native Egusi & Ogbono soups, piping hot pounded yam, 
                tender grilled chicken, and cold Chapman. Fast, hot delivery across Lagos or quick pickup.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
                <button
                  onClick={() => {
                    setCurrentPage('menu');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 bg-red-700 hover:bg-red-800 text-white font-bold text-base px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5 active:translate-y-0"
                >
                  <span>Order Your Favourite Food</span>
                  <ArrowRight className="w-5 h-5" />
                </button>

                <a
                  href={`https://wa.me/${whatsappPhone}?text=${encodeURIComponent('Hello Mary Restaurant! I would like to place an order.')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-base px-6 py-4 rounded-2xl transition-all shadow-md"
                >
                  <Phone className="w-5 h-5" />
                  <span>WhatsApp: {displayPhone}</span>
                </a>
              </div>

              {/* Guarantees / Value props */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-stone-200/80 text-left">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-red-700 font-bold text-xs sm:text-sm">
                    <Clock className="w-4 h-4" />
                    <span>30 - 45 Mins</span>
                  </div>
                  <p className="text-[11px] sm:text-xs text-stone-600">Fast Island & Mainland Dispatch</p>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-red-700 font-bold text-xs sm:text-sm">
                    <Flame className="w-4 h-4" />
                    <span>100% Native</span>
                  </div>
                  <p className="text-[11px] sm:text-xs text-stone-600">Pure Local Spices & Stockfish</p>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-red-700 font-bold text-xs sm:text-sm">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Safe Payment</span>
                  </div>
                  <p className="text-[11px] sm:text-xs text-stone-600">Direct Bank Transfer or Online</p>
                </div>
              </div>
            </div>

            {/* Right Column: Hero Visual Showcase */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none">
                {/* Decorative glow */}
                <div className="absolute -inset-4 bg-gradient-to-tr from-red-600/20 to-amber-500/20 rounded-3xl blur-2xl transform -rotate-3" />
                
                {/* Main Image Showcase Card */}
                <div className="relative rounded-3xl overflow-hidden border-2 border-white shadow-2xl bg-white">
                  <img
                    src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=1000&auto=format&fit=crop&q=85"
                    alt="Authentic Nigerian Jollof Rice with Fried Plantain and Chicken"
                    className="w-full h-80 sm:h-96 object-cover"
                  />
                  
                  {/* Floating Chef Recommendation Sticker */}
                  <div className="absolute bottom-4 left-4 right-4 bg-stone-900/90 backdrop-blur-md text-white p-4 rounded-2xl border border-stone-700 flex items-center justify-between">
                    <div>
                      <span className="block text-xs uppercase tracking-wider text-amber-400 font-bold">
                        Top Rated Dish
                      </span>
                      <h3 className="text-sm sm:text-base font-bold font-serif">
                        Smoky Party Jollof & Chicken
                      </h3>
                      <span className="text-xs text-stone-300">Served with fried sweet plantains</span>
                    </div>
                    <div className="text-right">
                      <span className="block text-base font-extrabold text-amber-400">₦3,800</span>
                      <button
                        onClick={() => {
                          const jollof = products.find((p) => p.id === 'jollof-rice-chicken');
                          if (jollof) onSelectProduct(jollof);
                        }}
                        className="text-xs bg-red-600 hover:bg-red-700 px-3 py-1 rounded-md text-white font-semibold transition-colors mt-1"
                      >
                        View Meal
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. FOOD CATEGORIES BAR */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-8 gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-red-700 mb-1">
              <UtensilsCrossed className="w-4 h-4" />
              <span>Explore Categories</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-serif">
              What Are You Craving Today?
            </h2>
          </div>

          <button
            onClick={() => {
              setSelectedCategory('all');
              setCurrentPage('menu');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-sm font-bold text-red-700 hover:text-red-800 flex items-center gap-1 group"
          >
            <span>View Full Menu ({products.length} Dishes)</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
          {categories.map((cat) => {
            const count = products.filter((p) => p.category_id === cat.id).length;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedCategory(cat.id);
                  setCurrentPage('menu');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="group p-5 bg-white rounded-2xl border border-stone-200/80 hover:border-red-500 hover:shadow-lg transition-all text-left flex flex-col justify-between"
              >
                <div>
                  <h3 className="font-bold text-stone-900 group-hover:text-red-700 transition-colors text-base font-serif">
                    {cat.name}
                  </h3>
                  <p className="text-xs text-stone-500 line-clamp-2 mt-1">
                    {cat.description}
                  </p>
                </div>
                <div className="mt-4 flex items-center justify-between text-xs font-semibold text-red-700 pt-3 border-t border-stone-100">
                  <span>{count} Meals</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* 3. FEATURED DISHES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-8 gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-red-700 mb-1">
              <Sparkles className="w-4 h-4" />
              <span>Chef's Choice</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-serif">
              Signature Nigerian Specialties
            </h2>
          </div>
          <p className="text-sm text-stone-600 max-w-md">
            Prepared every morning with fresh vegetables, premium cuts of beef, goat meat, and traditional locust beans.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => {
            const category = categories.find((c) => c.id === product.category_id);
            return (
              <FoodCard
                key={product.id}
                product={product}
                categoryName={category?.name}
                onSelect={onSelectProduct}
              />
            );
          })}
        </div>
      </section>

      {/* 4. PROMOTIONAL BANNER: WHATSAPP DIRECT ORDER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-stone-950 text-white p-8 sm:p-12 border border-stone-800 shadow-xl">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            <div className="md:col-span-8 space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-red-400">
                Direct Kitchen Line
              </span>
              <h3 className="text-2xl sm:text-4xl font-bold font-serif leading-tight">
                Hosting an event or craving a custom Nigerian banquet?
              </h3>
              <p className="text-stone-300 text-sm sm:text-base leading-relaxed max-w-2xl">
                Chat directly with Chef Mary and our order dispatch team on WhatsApp. 
                Custom bulk trays, corporate lunch packs, and urgent deliveries are welcomed!
              </p>
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <a
                  href={`https://wa.me/${whatsappPhone}?text=${encodeURIComponent('Hello Mary Restaurant! I need a custom catering quote or group meal order.')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 px-6 rounded-xl transition-all shadow-md"
                >
                  <Phone className="w-5 h-5" />
                  <span>Chat on WhatsApp: {displayPhone}</span>
                </a>
                <span className="text-xs text-stone-400">
                  Instant replies during opening hours
                </span>
              </div>
            </div>

            <div className="md:col-span-4 bg-stone-900/90 rounded-2xl p-6 border border-stone-800 text-stone-300 text-xs sm:text-sm space-y-3">
              <div className="font-bold text-white text-base font-serif border-b border-stone-800 pb-2">
                Mary Restaurant Kitchen
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-red-500 shrink-0" />
                <span>14 Adeola Odeku St, Victoria Island, Lagos</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-red-500 shrink-0" />
                <span>8:00 AM - 10:00 PM Daily</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-red-500 shrink-0" />
                <span>Delivery flat rate: {formatNaira(settings?.delivery_fee || 1500)}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. POPULAR MEALS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-8 gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-red-700 mb-1">
              <Flame className="w-4 h-4" />
              <span>Customer Favorites</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-serif">
              Popular Daily Meals
            </h2>
          </div>

          <button
            onClick={() => {
              setCurrentPage('menu');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-sm font-bold text-red-700 hover:text-red-800 flex items-center gap-1 group"
          >
            <span>Browse All Menu Items</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {popularMeals.map((product) => {
            const category = categories.find((c) => c.id === product.category_id);
            return (
              <FoodCard
                key={product.id}
                product={product}
                categoryName={category?.name}
                onSelect={onSelectProduct}
              />
            );
          })}
        </div>
      </section>

      {/* 6. TESTIMONIALS */}
      <section className="bg-stone-100/70 border-y border-stone-200/80 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-red-700">
              Verified Customers
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-serif mt-1">
              What Lagos Food Lovers Are Saying
            </h2>
            <p className="text-stone-600 text-sm mt-2">
              From Island corporate lunches to family dinners across the Mainland.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((item, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-6 border border-stone-200/80 shadow-sm flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center gap-1 text-amber-500 mb-3">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  <p className="text-stone-700 text-sm italic leading-relaxed">
                    "{item.comment}"
                  </p>
                </div>

                <div className="pt-4 border-t border-stone-100 flex items-center justify-between">
                  <div>
                    <span className="block text-sm font-bold text-stone-900 font-serif">
                      {item.name}
                    </span>
                    <span className="block text-xs text-stone-500">
                      {item.location}
                    </span>
                  </div>
                  <span className="text-[11px] text-red-700 font-semibold bg-red-50 px-2 py-1 rounded">
                    {item.dish}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. LOCATION & OPENING HOURS CARD */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl border border-stone-200 p-8 sm:p-12 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-red-700">
              Visit or Pick Up
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-stone-950 font-serif">
              Our Kitchen & Dining Hub
            </h2>
            <p className="text-stone-600 text-sm leading-relaxed">
              Drop by for a warm dine-in experience or choose pickup at checkout for instant grab-and-go. 
              Our kitchen operates 7 days a week with hot, freshly prepared meals.
            </p>

            <div className="space-y-3 pt-2 text-sm text-stone-700">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-stone-900">Address:</span>
                  <p>{settings?.physical_address || '14 Adeola Odeku Street, Victoria Island, Lagos, Nigeria'}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-stone-900">Opening Hours:</span>
                  <p>{settings?.opening_hours || 'Monday - Sunday: 8:00 AM - 10:00 PM'}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-stone-900">Customer Care & Dispatch:</span>
                  <p>{displayPhone} / +234 902 497 1419</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-stone-50 rounded-2xl p-6 border border-stone-200 flex flex-col justify-center space-y-6 text-center">
            <div className="w-16 h-16 bg-red-100 text-red-700 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
              <UtensilsCrossed className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-xl font-bold font-serif text-stone-900">
                Ready to Taste Authentic Nigeria?
              </h3>
              <p className="text-xs text-stone-500 mt-1">
                Select your dishes now and choose delivery or takeaway.
              </p>
            </div>
            <button
              onClick={() => {
                setCurrentPage('menu');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="bg-red-700 hover:bg-red-800 text-white font-bold py-3.5 px-6 rounded-xl shadow-md transition-all text-sm"
            >
              Start Your Order Now
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
