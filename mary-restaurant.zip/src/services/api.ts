import { Order, Product, Category, RestaurantSettings } from '../types';

export const API_BASE = '/api';

export const api = {
  // Menu & Categories
  async getMenu(): Promise<{ products: Product[]; categories: Category[] }> {
    const res = await fetch(`${API_BASE}/menu`);
    if (!res.ok) throw new Error('Failed to fetch menu');
    return res.json();
  },

  // Settings
  async getSettings(): Promise<RestaurantSettings> {
    const res = await fetch(`${API_BASE}/settings`);
    if (!res.ok) throw new Error('Failed to fetch restaurant settings');
    return res.json();
  },

  async updateSettings(settings: Partial<RestaurantSettings>, token?: string): Promise<{ success: boolean; settings: RestaurantSettings }> {
    const res = await fetch(`${API_BASE}/admin/settings`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: token ? `Bearer ${token}` : '',
      },
      body: JSON.stringify(settings),
    });
    if (!res.ok) throw new Error('Failed to update settings');
    return res.json();
  },

  // Orders
  async createOrder(orderPayload: {
    customer_name: string;
    customer_phone: string;
    delivery_address: string;
    delivery_method: 'delivery' | 'pickup';
    delivery_instructions?: string;
    payment_method: 'bank_transfer' | 'online_payment';
    payment_reference?: string;
    items: { product_id: string; quantity: number }[];
  }): Promise<{ success: boolean; order: Order }> {
    const res = await fetch(`${API_BASE}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderPayload),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to submit order');
    }
    return data;
  },

  async getOrderByNumber(orderNumber: string): Promise<{ order: Order }> {
    const res = await fetch(`${API_BASE}/orders/${encodeURIComponent(orderNumber)}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Order not found');
    return data;
  },

  // Admin Operations
  async adminLogin(username: string, password: string):Promise<{ success: boolean; user: any; token: string }> {
    const res = await fetch(`${API_BASE}/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Invalid credentials');
    return data;
  },

  async getAdminOrders(token?: string): Promise<{ orders: Order[] }> {
    const res = await fetch(`${API_BASE}/admin/orders`, {
      headers: { Authorization: token ? `Bearer ${token}` : '' },
    });
    if (!res.ok) throw new Error('Failed to fetch admin orders');
    return res.json();
  },

  async updateOrderStatus(orderId: string, order_status: string, token?: string): Promise<{ success: boolean; order: Order }> {
    const res = await fetch(`${API_BASE}/admin/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: token ? `Bearer ${token}` : '',
      },
      body: JSON.stringify({ order_status }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update order status');
    return data;
  },

  async verifyPayment(orderId: string, status: string = 'paid', token?: string): Promise<{ success: boolean; order: Order; message: string }> {
    const res = await fetch(`${API_BASE}/admin/orders/${orderId}/verify-payment`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: token ? `Bearer ${token}` : '',
      },
      body: JSON.stringify({ status }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to verify payment');
    return data;
  },

  async addProduct(product: Partial<Product>, token?: string): Promise<{ product: Product }> {
    const res = await fetch(`${API_BASE}/admin/products`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: token ? `Bearer ${token}` : '',
      },
      body: JSON.stringify(product),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to add dish');
    return data;
  },

  async updateProduct(id: string, updates: Partial<Product>, token?: string): Promise<{ product: Product }> {
    const res = await fetch(`${API_BASE}/admin/products/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: token ? `Bearer ${token}` : '',
      },
      body: JSON.stringify(updates),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update dish');
    return data;
  },

  async deleteProduct(id: string, token?: string): Promise<{ success: boolean }> {
    const res = await fetch(`${API_BASE}/admin/products/${id}`, {
      method: 'DELETE',
      headers: { Authorization: token ? `Bearer ${token}` : '' },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete dish');
    return data;
  },

  async testSupabase(url: string, key: string): Promise<{ success: boolean; message: string; error?: string; hint?: string }> {
    const res = await fetch(`${API_BASE}/supabase/test`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, key }),
    });
    return res.json();
  },

  async initializePaystack(order_number: string, amount: number, email?: string) {
    const res = await fetch(`${API_BASE}/paystack/initialize`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ order_number, amount, email }),
    });
    return res.json();
  },

  async verifyPaystack(reference: string, order_number: string) {
    const res = await fetch(`${API_BASE}/paystack/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reference, order_number }),
    });
    return res.json();
  },
};
