export interface Category {
  id: string;
  name: string;
  description?: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image_url: string;
  category_id: string;
  is_available: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type DeliveryMethod = 'delivery' | 'pickup';
export type PaymentMethod = 'bank_transfer' | 'online_payment';
export type OrderStatus = 'pending' | 'confirmed' | 'preparing' | 'out_for_delivery' | 'delivered' | 'cancelled';
export type PaymentStatus = 'unpaid' | 'pending_verification' | 'paid' | 'refunded' | 'failed';

export interface OrderItem {
  id?: string;
  order_id?: string;
  product_id: string;
  product_name: string;
  unit_price: number;
  quantity: number;
  line_total: number;
}

export interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  customer_phone: string;
  delivery_address: string;
  delivery_method: DeliveryMethod;
  delivery_instructions?: string;
  subtotal: number;
  delivery_fee: number;
  total_amount: number;
  order_status: OrderStatus;
  payment_status: PaymentStatus;
  payment_method: PaymentMethod;
  payment_reference?: string;
  created_at: string;
  items: OrderItem[];
}

export interface RestaurantSettings {
  id: number;
  restaurant_name: string;
  whatsapp_number: string;
  phone_display: string;
  email_contact: string;
  physical_address: string;
  bank_name: string;
  bank_account_name: string;
  bank_account_number: string;
  opening_hours: string;
  delivery_fee: number;
  min_order_amount?: number;
  supabase_url?: string;
  supabase_anon_key?: string;
  updated_at?: string;
}

export type PageRoute =
  | 'home'
  | 'menu'
  | 'food-detail'
  | 'cart'
  | 'checkout'
  | 'order-confirmation'
  | 'about'
  | 'contact'
  | 'privacy'
  | 'admin-login'
  | 'admin-dashboard';
