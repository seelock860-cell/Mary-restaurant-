-- =====================================================================
-- MARY RESTAURANT - DATABASE SCHEMA & MIGRATIONS
-- Compatible with Supabase PostgreSQL (with Row Level Security)
-- =====================================================================

-- 1. PROFILES TABLE (User profiles with role-based access)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'admin', 'staff')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Profiles Policies
DROP POLICY IF EXISTS "Public can view admin/staff profiles" ON public.profiles;
CREATE POLICY "Public can view admin/staff profiles"
  ON public.profiles FOR SELECT
  USING (role IN ('admin', 'staff'));

DROP POLICY IF EXISTS "Users can read own profile" ON public.profiles;
CREATE POLICY "Users can read own profile"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "Admins can view and manage all profiles" ON public.profiles;
CREATE POLICY "Admins can view and manage all profiles"
  ON public.profiles FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- 2. CATEGORIES TABLE
CREATE TABLE IF NOT EXISTS public.categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- Enable RLS on categories
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

-- Anyone can view categories
DROP POLICY IF EXISTS "Anyone can view categories" ON public.categories;
CREATE POLICY "Anyone can view categories"
  ON public.categories FOR SELECT
  USING (true);

-- Only verified admins can insert/update/delete categories
DROP POLICY IF EXISTS "Admins can manage categories" ON public.categories;
CREATE POLICY "Admins can manage categories"
  ON public.categories FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- 3. PRODUCTS (FOOD MENU ITEMS)
CREATE TABLE IF NOT EXISTS public.products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  price NUMERIC(12, 2) NOT NULL CHECK (price >= 0),
  image_url TEXT NOT NULL,
  category_id TEXT NOT NULL REFERENCES public.categories(id) ON DELETE RESTRICT,
  is_available BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_products_category ON public.products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_availability ON public.products(is_available);

-- Enable RLS on products
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- Anyone can view available and active products
DROP POLICY IF EXISTS "Anyone can view products" ON public.products;
CREATE POLICY "Anyone can view products"
  ON public.products FOR SELECT
  USING (true);

-- Only verified admins can modify products
DROP POLICY IF EXISTS "Admins can manage products" ON public.products;
CREATE POLICY "Admins can manage products"
  ON public.products FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- 4. ORDERS TABLE
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  delivery_address TEXT NOT NULL,
  delivery_method TEXT NOT NULL CHECK (delivery_method IN ('delivery', 'pickup')),
  delivery_instructions TEXT,
  subtotal NUMERIC(12, 2) NOT NULL CHECK (subtotal >= 0),
  delivery_fee NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (delivery_fee >= 0),
  total_amount NUMERIC(12, 2) NOT NULL CHECK (total_amount >= 0),
  order_status TEXT NOT NULL DEFAULT 'pending' CHECK (order_status IN ('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled')),
  payment_status TEXT NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid', 'pending_verification', 'paid', 'refunded', 'failed')),
  payment_method TEXT NOT NULL CHECK (payment_method IN ('bank_transfer', 'online_payment', 'cash_on_delivery')),
  payment_reference TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

CREATE INDEX IF NOT EXISTS idx_orders_order_number ON public.orders(order_number);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON public.orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(order_status);

-- Enable RLS on orders
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Anyone can insert an order (Checkout submission)
DROP POLICY IF EXISTS "Anyone can insert orders" ON public.orders;
CREATE POLICY "Anyone can insert orders"
  ON public.orders FOR INSERT
  WITH CHECK (true);

-- Customers can view their specific order by order_number
DROP POLICY IF EXISTS "Public can lookup order by order_number" ON public.orders;
CREATE POLICY "Public can lookup order by order_number"
  ON public.orders FOR SELECT
  USING (true);

-- Admins can update and manage all orders
DROP POLICY IF EXISTS "Admins can manage orders" ON public.orders;
CREATE POLICY "Admins can manage orders"
  ON public.orders FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- 5. ORDER ITEMS TABLE
CREATE TABLE IF NOT EXISTS public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id TEXT NOT NULL,
  product_name TEXT NOT NULL,
  unit_price NUMERIC(12, 2) NOT NULL CHECK (unit_price >= 0),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  line_total NUMERIC(12, 2) NOT NULL CHECK (line_total >= 0)
);

CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON public.order_items(order_id);

-- Enable RLS on order_items
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can insert order items with order" ON public.order_items;
CREATE POLICY "Anyone can insert order items with order"
  ON public.order_items FOR INSERT
  WITH CHECK (true);

DROP POLICY IF EXISTS "Anyone can read order items for viewed order" ON public.order_items;
CREATE POLICY "Anyone can read order items for viewed order"
  ON public.order_items FOR SELECT
  USING (true);

-- 6. PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  payment_provider TEXT NOT NULL CHECK (payment_provider IN ('bank_transfer', 'paystack', 'flutterwave')),
  transaction_reference TEXT NOT NULL,
  amount NUMERIC(12, 2) NOT NULL CHECK (amount >= 0),
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'verified', 'failed')),
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can insert payment record" ON public.payments;
CREATE POLICY "Anyone can insert payment record"
  ON public.payments FOR INSERT
  WITH CHECK (true);

DROP POLICY IF EXISTS "Admins can view and verify payments" ON public.payments;
CREATE POLICY "Admins can view and verify payments"
  ON public.payments FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- 7. RESTAURANT SETTINGS TABLE
CREATE TABLE IF NOT EXISTS public.restaurant_settings (
  id INTEGER PRIMARY KEY DEFAULT 1,
  restaurant_name TEXT NOT NULL DEFAULT 'MARY RESTAURANT',
  whatsapp_number TEXT NOT NULL DEFAULT '2349024971419',
  phone_display TEXT NOT NULL DEFAULT '09024971419',
  email_contact TEXT NOT NULL DEFAULT 'orders@maryrestaurant.ng',
  physical_address TEXT NOT NULL DEFAULT '14 Adeola Odeku Street, Victoria Island, Lagos, Nigeria',
  bank_name TEXT NOT NULL DEFAULT 'Zenith Bank',
  bank_account_name TEXT NOT NULL DEFAULT 'MARY RESTAURANT ENTERPRISES',
  bank_account_number TEXT NOT NULL DEFAULT '1018944521',
  opening_hours TEXT NOT NULL DEFAULT 'Monday - Sunday: 8:00 AM - 10:00 PM',
  delivery_fee NUMERIC(12, 2) NOT NULL DEFAULT 1500.00,
  min_order_amount NUMERIC(12, 2) NOT NULL DEFAULT 2000.00,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

ALTER TABLE public.restaurant_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public can view restaurant settings" ON public.restaurant_settings;
CREATE POLICY "Public can view restaurant settings"
  ON public.restaurant_settings FOR SELECT
  USING (true);

DROP POLICY IF EXISTS "Admins can update restaurant settings" ON public.restaurant_settings;
CREATE POLICY "Admins can update restaurant settings"
  ON public.restaurant_settings FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid() AND profiles.role = 'admin'
    )
  );

-- =====================================================================
-- SEED INITIAL DATA
-- =====================================================================

-- Seed restaurant settings
INSERT INTO public.restaurant_settings (id, restaurant_name, whatsapp_number, phone_display, email_contact, physical_address, bank_name, bank_account_name, bank_account_number, opening_hours, delivery_fee)
VALUES (
  1,
  'MARY RESTAURANT',
  '2349024971419',
  '09024971419',
  'orders@maryrestaurant.ng',
  '14 Adeola Odeku Street, Victoria Island, Lagos, Nigeria',
  'Zenith Bank',
  'MARY RESTAURANT ENTERPRISES',
  '1018944521',
  'Monday - Sunday: 8:00 AM - 10:00 PM',
  1500.00
) ON CONFLICT (id) DO NOTHING;

-- Seed categories
INSERT INTO public.categories (id, name, description) VALUES
  ('rice-dishes', 'Rice Dishes', 'Smoky Jollof, savory fried rice, and aromatic white rice with slow-cooked stews.'),
  ('soups-swallows', 'Native Soups & Swallows', 'Rich, traditional Nigerian soups served with pounded yam, eba, amala, or fufu.'),
  ('proteins-grills', 'Proteins & Grills', 'Succulent grilled chicken, spicy peppered meats, and fish cooked to perfection.'),
  ('sides-snacks', 'Sides & Snacks', 'Crispy sweet plantains, freshly wrapped moi moi, and authentic bites.'),
  ('drinks-beverages', 'Drinks & Refreshments', 'Chilled Nigerian Chapman, cold malts, juices, and pure bottled water.')
ON CONFLICT (id) DO NOTHING;

-- Seed initial Nigerian dishes
INSERT INTO public.products (id, name, description, price, image_url, category_id, is_available) VALUES
  ('jollof-rice-chicken', 'Smoky Party Jollof Rice & Chicken', 'Signature Nigerian party jollof cooked with firewood smokiness, fresh tomato-pepper blend, seasoned tender chicken quarter, and fried plantain.', 3800.00, 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80', 'rice-dishes', true),
  ('special-fried-rice', 'Special Nigerian Fried Rice', 'Fragrant savory long-grain rice tossed with seasoned liver bits, carrots, sweet corn, green peas, and served with crispy fried chicken.', 4000.00, 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=800&auto=format&fit=crop&q=80', 'rice-dishes', true),
  ('white-rice-stew', 'White Rice & Buka Stew', 'Fluffy steamed white rice served with deep, slow-cooked Nigerian pepper stew, boiled egg, and succulent beef pieces.', 3500.00, 'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=800&auto=format&fit=crop&q=80', 'rice-dishes', true),
  ('beans-plantain', 'Ewa Aganyin & Dodo', 'Tender slow-cooked honey beans paired with smoky, spicy palm oil Aganyin pepper sauce and golden sweet fried plantains.', 2800.00, 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800&auto=format&fit=crop&q=80', 'rice-dishes', true),
  ('egusi-pounded-yam', 'Egusi Soup with Pounded Yam & Goat Meat', 'Richly ground melon seeds slow-cooked with fresh spinach, crayfish, smoked stockfish, and tender goat meat, served with soft pounded yam.', 5200.00, 'https://images.unsplash.com/photo-1543339308-43e59d6b73a6?w=800&auto=format&fit=crop&q=80', 'soups-swallows', true),
  ('ogbono-soup-eba', 'Ogbono Soup with Assorted Meat & Eba', 'Nutritious wild mango seed soup cooked with dry fish, beef, and tripe, paired with piping hot yellow garri eba.', 4800.00, 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=800&auto=format&fit=crop&q=80', 'soups-swallows', true),
  ('okra-soup-fufu', 'Fisherman Fresh Okra Soup & Fufu', 'Hand-chopped crunchy okra simmered with fresh sea fish, prawns, and hot peppers, served with smooth fufu.', 5500.00, 'https://images.unsplash.com/photo-1547592180-85f173990554?w=800&auto=format&fit=crop&q=80', 'soups-swallows', true),
  ('vegetable-soup-efo', 'Efo Riro (Rich Vegetable Soup) & Pounded Yam', 'Yoruba-style rich green vegetable stew simmered with locust beans (iru), smoked catfish, shaki, and cow leg, served with pounded yam.', 5000.00, 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=800&auto=format&fit=crop&q=80', 'soups-swallows', true),
  ('amala-ewedu-gbegiri', 'Amala with Abula (Ewedu & Gbegiri)', 'Silky dark amala served with smooth gbegiri bean broth, fresh ewedu, fiery buka stew, and soft cow tripe & goat meat.', 5200.00, 'https://images.unsplash.com/photo-1514944298352-78d1209b5557?w=800&auto=format&fit=crop&q=80', 'soups-swallows', true),
  ('pounded-yam-extra', 'Extra Pounded Yam', 'Freshly pounded soft and stretchy yam swallow.', 1000.00, 'https://images.unsplash.com/photo-1543339308-43e59d6b73a6?w=800&auto=format&fit=crop&q=80', 'soups-swallows', true),
  ('eba-extra', 'Extra Eba (Yellow Garri)', 'Traditional hot turned yellow garri swallow.', 800.00, 'https://images.unsplash.com/photo-1574484284002-952d92456975?w=800&auto=format&fit=crop&q=80', 'soups-swallows', true),
  ('fufu-extra', 'Extra Smooth Fufu', 'Freshly prepared fermented cassava fufu.', 800.00, 'https://images.unsplash.com/photo-1547592180-85f173990554?w=800&auto=format&fit=crop&q=80', 'soups-swallows', true),
  ('grilled-chicken-quarter', 'Flame-Grilled Chicken Quarter', 'Charcoal-grilled chicken quarter rubbed in aromatic suya spices, ginger, and garlic.', 3200.00, 'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?w=800&auto=format&fit=crop&q=80', 'proteins-grills', true),
  ('peppered-fried-chicken', 'Crispy Peppered Fried Chicken', 'Golden-fried crispy chicken glazed in fiery scotch bonnet and sweet bell pepper reduction.', 3200.00, 'https://images.unsplash.com/photo-1562967914-608f82629710?w=800&auto=format&fit=crop&q=80', 'proteins-grills', true),
  ('special-moi-moi', 'Special Steamed Moi Moi', 'Steamed rich bean pudding infused with flaked fish, boiled egg, and ground crayfish.', 1200.00, 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800&auto=format&fit=crop&q=80', 'sides-snacks', true),
  ('fried-plantain-dodo', 'Fried Sweet Plantain (Dodo)', 'Sweet ripe plantain slices fried golden brown and caramelized.', 1000.00, 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=800&auto=format&fit=crop&q=80', 'sides-snacks', true),
  ('nigerian-chapman', 'Signature Chilled Chapman', 'Traditional Nigerian mocktail mixed with citrus soda, grenadine, cucumber slices, and aromatic bitters.', 1800.00, 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=800&auto=format&fit=crop&q=80', 'drinks-beverages', true),
  ('malta-guinness', 'Malta Guinness Can (330ml)', 'Ice-cold premium non-alcoholic malt beverage.', 1000.00, 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=800&auto=format&fit=crop&q=80', 'drinks-beverages', true),
  ('eva-bottled-water', 'Bottled Spring Water (75cl)', 'Pure, crisp chilled bottled water.', 500.00, 'https://images.unsplash.com/photo-1548839140-29a749e1bc4e?w=800&auto=format&fit=crop&q=80', 'drinks-beverages', true)
ON CONFLICT (id) DO NOTHING;
