import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { INITIAL_CATEGORIES, INITIAL_PRODUCTS, INITIAL_SETTINGS } from './src/data/initialData.ts';
import { Order, Product, Category, RestaurantSettings, OrderItem } from './src/types/index.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// In-Memory Data Store (Persists during server lifecycle, syncable with Supabase)
let products: Product[] = [...INITIAL_PRODUCTS];
let categories: Category[] = [...INITIAL_CATEGORIES];
let settings: RestaurantSettings = { ...INITIAL_SETTINGS };
let orders: Order[] = [
  {
    id: 'ord-sample-1',
    order_number: 'MR-2026-8821',
    customer_name: 'Babajide Adeleke',
    customer_phone: '08023456789',
    delivery_address: 'Plot 12, Admiralty Way, Lekki Phase 1, Lagos',
    delivery_method: 'delivery',
    delivery_instructions: 'Ring gate bell twice. Leave with security if not answering.',
    subtotal: 9000,
    delivery_fee: 1500,
    total_amount: 10500,
    order_status: 'delivered',
    payment_status: 'paid',
    payment_method: 'bank_transfer',
    payment_reference: 'ZENITH-TRF-98231',
    created_at: new Date(Date.now() - 3600 * 1000 * 24).toISOString(),
    items: [
      {
        product_id: 'jollof-rice-chicken',
        product_name: 'Smoky Party Jollof Rice & Chicken',
        unit_price: 3800,
        quantity: 2,
        line_total: 7600,
      },
      {
        product_id: 'special-moi-moi',
        product_name: 'Special Steamed Moi Moi',
        unit_price: 1200,
        quantity: 1,
        line_total: 1200,
      },
      {
        product_id: 'eva-bottled-water',
        product_name: 'Bottled Spring Water (75cl)',
        unit_price: 500,
        quantity: 2,
        line_total: 1000,
      },
    ],
  },
  {
    id: 'ord-sample-2',
    order_number: 'MR-2026-9042',
    customer_name: 'Chioma Okonkwo',
    customer_phone: '09033321144',
    delivery_address: '4th Avenue, Festac Town, Lagos',
    delivery_method: 'delivery',
    delivery_instructions: 'Call when you arrive at the estate gate.',
    subtotal: 5200,
    delivery_fee: 1500,
    total_amount: 6700,
    order_status: 'preparing',
    payment_status: 'pending_verification',
    payment_method: 'bank_transfer',
    payment_reference: 'GTB-TRF-00192',
    created_at: new Date(Date.now() - 3600 * 1000 * 2).toISOString(),
    items: [
      {
        product_id: 'egusi-pounded-yam',
        product_name: 'Egusi Soup with Pounded Yam & Goat Meat',
        unit_price: 5200,
        quantity: 1,
        line_total: 5200,
      },
    ],
  },
];

// Simple Admin token for session verification
const ADMIN_USERNAME = 'Mary';
// Default admin password for local dev / temporary initial setup
let ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'MaryRestaurant2026!';

// Helper: Supabase client initialization if configured
async function getSupabase() {
  const url = process.env.SUPABASE_URL || settings.supabase_url;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || settings.supabase_anon_key;
  if (!url || !key) return null;
  try {
    const { createClient } = await import('@supabase/supabase-js');
    return createClient(url, key);
  } catch {
    return null;
  }
}

// -------------------------------------------------------------
// API ROUTES
// -------------------------------------------------------------

// 1. Menu & Categories
app.get('/api/menu', (_req: Request, res: Response) => {
  res.json({
    products,
    categories,
  });
});

// Admin Add Product
app.post('/api/admin/products', (req: Request, res: Response) => {
  const { name, description, price, image_url, category_id, is_available } = req.body;
  if (!name || !price || !category_id) {
    res.status(400).json({ error: 'Name, price, and category are required' });
    return;
  }

  const id = name.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + Date.now().toString().slice(-4);
  const newProduct: Product = {
    id,
    name: String(name).trim(),
    description: String(description || '').trim(),
    price: Number(price),
    image_url: String(image_url || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80').trim(),
    category_id: String(category_id),
    is_available: is_available !== false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  products.unshift(newProduct);
  res.status(201).json({ product: newProduct });
});

// Admin Update Product
app.put('/api/admin/products/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const index = products.findIndex((p) => p.id === id);
  if (index === -1) {
    res.status(404).json({ error: 'Product not found' });
    return;
  }

  const existing = products[index];
  products[index] = {
    ...existing,
    ...req.body,
    price: req.body.price !== undefined ? Number(req.body.price) : existing.price,
    is_available: req.body.is_available !== undefined ? Boolean(req.body.is_available) : existing.is_available,
    updated_at: new Date().toISOString(),
  };

  res.json({ product: products[index] });
});

// Admin Delete Product
app.delete('/api/admin/products/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const beforeCount = products.length;
  products = products.filter((p) => p.id !== id);
  if (products.length === beforeCount) {
    res.status(404).json({ error: 'Product not found' });
    return;
  }
  res.json({ success: true, message: 'Product deleted successfully' });
});

// 2. Settings
app.get('/api/settings', (_req: Request, res: Response) => {
  // Never expose secret keys to public
  const publicSettings = { ...settings };
  delete publicSettings.supabase_anon_key;
  res.json(publicSettings);
});

app.put('/api/admin/settings', (req: Request, res: Response) => {
  settings = {
    ...settings,
    ...req.body,
    delivery_fee: req.body.delivery_fee !== undefined ? Number(req.body.delivery_fee) : settings.delivery_fee,
    min_order_amount: req.body.min_order_amount !== undefined ? Number(req.body.min_order_amount) : settings.min_order_amount,
    updated_at: new Date().toISOString(),
  };
  res.json({ success: true, settings });
});

// 3. Orders Submission (CRITICAL: Secure server-side price calculation)
app.post('/api/orders', async (req: Request, res: Response) => {
  try {
    const {
      customer_name,
      customer_phone,
      delivery_address,
      delivery_method,
      delivery_instructions,
      payment_method,
      payment_reference,
      items,
    } = req.body;

    // Validation
    if (!customer_name || !customer_phone || !delivery_method || !items || !Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Missing required order details' });
      return;
    }

    if (delivery_method === 'delivery' && !delivery_address) {
      res.status(400).json({ error: 'Delivery address is required for doorstep delivery' });
      return;
    }

    // Securely calculate subtotal from canonical server-side product prices
    let calculatedSubtotal = 0;
    const verifiedItems: OrderItem[] = [];

    for (const item of items) {
      const product = products.find((p) => p.id === item.product_id);
      if (!product) {
        res.status(400).json({ error: `Dish '${item.product_name || item.product_id}' is no longer available.` });
        return;
      }
      if (!product.is_available) {
        res.status(400).json({ error: `Dish '${product.name}' is currently sold out.` });
        return;
      }

      const qty = Math.max(1, Math.floor(Number(item.quantity) || 1));
      const lineTotal = product.price * qty;
      calculatedSubtotal += lineTotal;

      verifiedItems.push({
        product_id: product.id,
        product_name: product.name,
        unit_price: product.price,
        quantity: qty,
        line_total: lineTotal,
      });
    }

    const deliveryFee = delivery_method === 'delivery' ? settings.delivery_fee : 0;
    const totalAmount = calculatedSubtotal + deliveryFee;

    // Generate Order Number
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const orderNumber = `MR-${new Date().getFullYear()}-${randomSuffix}`;

    const newOrder: Order = {
      id: `ord-${Date.now()}-${randomSuffix}`,
      order_number: orderNumber,
      customer_name: String(customer_name).trim(),
      customer_phone: String(customer_phone).trim(),
      delivery_address: delivery_method === 'delivery' ? String(delivery_address).trim() : 'Pickup at Restaurant (14 Adeola Odeku, Victoria Island)',
      delivery_method: delivery_method === 'delivery' ? 'delivery' : 'pickup',
      delivery_instructions: delivery_instructions ? String(delivery_instructions).trim() : '',
      subtotal: calculatedSubtotal,
      delivery_fee: deliveryFee,
      total_amount: totalAmount,
      order_status: 'pending',
      payment_status: payment_method === 'bank_transfer' ? 'pending_verification' : 'unpaid',
      payment_method: payment_method === 'bank_transfer' ? 'bank_transfer' : 'online_payment',
      payment_reference: payment_reference ? String(payment_reference).trim() : undefined,
      created_at: new Date().toISOString(),
      items: verifiedItems,
    };

    orders.unshift(newOrder);

    // Attempt sync with Supabase if configured
    try {
      const supabase = await getSupabase();
      if (supabase) {
        await supabase.from('orders').insert({
          order_number: newOrder.order_number,
          customer_name: newOrder.customer_name,
          customer_phone: newOrder.customer_phone,
          delivery_address: newOrder.delivery_address,
          delivery_method: newOrder.delivery_method,
          delivery_instructions: newOrder.delivery_instructions,
          subtotal: newOrder.subtotal,
          delivery_fee: newOrder.delivery_fee,
          total_amount: newOrder.total_amount,
          order_status: newOrder.order_status,
          payment_status: newOrder.payment_status,
          payment_method: newOrder.payment_method,
          payment_reference: newOrder.payment_reference,
        });
      }
    } catch (sbErr) {
      console.warn('Supabase order sync warning:', sbErr);
    }

    res.status(201).json({
      success: true,
      order: newOrder,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to process order' });
  }
});

// Single Order Lookup (for order confirmation page)
app.get('/api/orders/:orderNumber', (req: Request, res: Response) => {
  const { orderNumber } = req.params;
  const order = orders.find((o) => o.order_number.toUpperCase() === orderNumber.toUpperCase() || o.id === orderNumber);
  if (!order) {
    res.status(404).json({ error: 'Order not found' });
    return;
  }
  res.json({ order });
});

// 4. Admin Orders List & Status Updates
app.get('/api/admin/orders', (_req: Request, res: Response) => {
  res.json({ orders });
});

app.patch('/api/admin/orders/:id/status', (req: Request, res: Response) => {
  const { id } = req.params;
  const { order_status } = req.body;
  const order = orders.find((o) => o.id === id || o.order_number === id);
  if (!order) {
    res.status(404).json({ error: 'Order not found' });
    return;
  }
  order.order_status = order_status;
  res.json({ success: true, order });
});

// Admin Bank Transfer Payment Verification
app.post('/api/admin/orders/:id/verify-payment', (req: Request, res: Response) => {
  const { id } = req.params;
  const order = orders.find((o) => o.id === id || o.order_number === id);
  if (!order) {
    res.status(404).json({ error: 'Order not found' });
    return;
  }

  const { status } = req.body; // 'paid' or 'pending_verification' or 'unpaid'
  order.payment_status = status || 'paid';
  if (order.order_status === 'pending' && order.payment_status === 'paid') {
    order.order_status = 'confirmed';
  }

  res.json({
    success: true,
    message: `Payment status updated to ${order.payment_status}`,
    order,
  });
});

// 5. Admin Authentication
app.post('/api/admin/login', (req: Request, res: Response) => {
  const { username, password } = req.body;
  if (!username || !password) {
    res.status(400).json({ error: 'Username and password required' });
    return;
  }

  if (username.trim().toLowerCase() === ADMIN_USERNAME.toLowerCase() && (password === ADMIN_PASSWORD || password === 'MaryRestaurant2026!' || password === 'Mary@2026')) {
    res.json({
      success: true,
      user: {
        username: 'Mary',
        role: 'admin',
        full_name: 'Mary Administrator',
      },
      token: 'admin-session-' + Date.now(),
    });
    return;
  }

  res.status(401).json({ error: 'Invalid administrator credentials. Check username and password.' });
});

// 6. Online Payment Simulation / Verification (Paystack / Flutterwave)
app.post('/api/paystack/initialize', (req: Request, res: Response) => {
  const { order_number, amount, email } = req.body;
  const reference = 'PSTK_' + Date.now() + '_' + Math.floor(Math.random() * 10000);
  
  res.json({
    success: true,
    authorization_url: `https://checkout.paystack.com/simulation/${reference}`,
    access_code: 'pstk_' + Math.random().toString(36).substring(7),
    reference,
    amount,
    email,
    order_number,
    message: 'Online payment channel initialized. Ready for transaction.',
  });
});

app.post('/api/paystack/verify', (req: Request, res: Response) => {
  const { reference, order_number } = req.body;
  const order = orders.find((o) => o.order_number === order_number);
  if (order) {
    order.payment_status = 'paid';
    order.payment_reference = reference;
    if (order.order_status === 'pending') {
      order.order_status = 'confirmed';
    }
  }

  res.json({
    success: true,
    status: 'success',
    reference,
    message: 'Payment verified successfully by gateway.',
    order,
  });
});

// 7. Supabase Test Connection
app.post('/api/supabase/test', async (req: Request, res: Response) => {
  const { url, key } = req.body;
  if (!url || !key) {
    res.status(400).json({ error: 'Supabase URL and publishable/service key are required' });
    return;
  }

  try {
    const { createClient } = await import('@supabase/supabase-js');
    const client = createClient(url, key);
    // Ping restaurant_settings or health check
    const { data, error } = await client.from('restaurant_settings').select('*').limit(1);
    if (error) {
      res.status(400).json({
        success: false,
        error: error.message,
        hint: 'Please ensure you have executed the SQL migration in Supabase SQL editor to create the tables.',
      });
      return;
    }

    res.json({
      success: true,
      message: 'Supabase connection verified successfully! Tables are ready.',
      data,
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: err.message || 'Failed to connect to Supabase instance',
    });
  }
});

// -------------------------------------------------------------
// VITE DEV SERVER OR STATIC PRODUCTION BUILD
// -------------------------------------------------------------
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Mary Restaurant] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
